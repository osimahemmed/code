package com.sape.generics;

public class A {
	
	public A() {
		System.out.println("A constructor");
	}

}
