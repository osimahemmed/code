package com.sape.immutable;

public class Mutable extends Immutable {
	
	private int realValue;
	public Mutable(int value) {
		super(value);
		realValue = value;
	}
	
	public int getValue() {
		return realValue;
	}
	public void setValue(int newValue) {
		realValue = newValue;
	}

	public static void main(String[] args) {
		Mutable mut = new Mutable(4);
		Immutable immObj = (Immutable)mut; 
		System.out.println(immObj.getValue());
		mut.setValue(10);
		System.out.println(immObj.getValue());
	}
}
