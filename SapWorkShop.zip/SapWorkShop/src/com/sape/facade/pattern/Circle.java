package com.sape.facade.pattern;

public class Circle implements Shape {
	
	@Override
	public void draw() {
		System.out.println("Drawing circle");
	}
}
