package com.sape.override;

public class MainCastTest {

	public static void main(String[] args) {
		Cat cat = new Cat();
		Animal an = new Cat();
		((Cat)an).meow();
		an = (Cat)cat;
		Animal animal = cat;
		animal.eat();

	}

}
