package com.java.design.pattern;

public interface Strategy {
	public int doOperation(int a, int b);

}
