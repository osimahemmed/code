package com.sape.mockito;

public interface ICalculator {
	int add(int x, int y);
}
