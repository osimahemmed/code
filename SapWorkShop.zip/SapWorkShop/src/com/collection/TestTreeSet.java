package com.collection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class TestTreeSet {

	public static void main(String[] args) {
		
		Queue<Integer> queue = new PriorityQueue<Integer>();
		
		queue.add(2);
		queue.add(0);
		queue.add(9);
		queue.add(6);
		queue.add(3);
		
		Iterator<Integer> itr = queue.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("size " +queue.size());
		System.out.println("get value " +queue.size());
		String s = "Sapient";
		Employee emp = new Employee(1,"A");
		Map<String, String> map = new TreeMap<>();
		map.put(s, "1");
		
		Set<Employee> tr = new TreeSet<Employee>();
		tr.add(emp);

	}

}
