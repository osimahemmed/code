package com.sape.java8;

public class Test1 implements ITest1, ITest {
	
	public void defaultMethod1() {
		ITest1.super.defaultMethod1();
		ITest1.super.defaultMethod2();
		ITest.super.defaultMethod1();
	}
	
	public static void main(String args[]) {
		ITest1 tst = new Test1();
		tst.defaultMethod1();
	}
	
	
}
