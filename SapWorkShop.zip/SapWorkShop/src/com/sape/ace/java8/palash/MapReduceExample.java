package com.sape.ace.java8.palash;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public class MapReduceExample {

	public static void main(String[] args) {
		
		List<Integer> list = Arrays.asList(1, 2, 3, 4, 5);
		Optional<String> opt =  list.stream().map(i -> Integer.toString(i)).reduce((a, b) -> a +"," +b);
		System.out.println(opt);
		
		//Stream<Integer> listStream = list.m.stream().reduce((a, b) -> a +"," +b);

	}

}
