package com.java.lambda.expression;

import java.util.function.BinaryOperator;
import java.util.function.Supplier;

public class TestExp {

	public static void main(String[] args) {
		Supplier<String> s = ()->"Java function";
		System.out.println(s.get());
		
		BinaryOperator<Integer> add  = (a,b) -> a+b;
		System.out.println("add 10 +25: " + add.apply(10, 25));
		

	}

}
