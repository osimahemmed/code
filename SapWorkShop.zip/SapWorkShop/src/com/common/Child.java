package com.common;

class Child extends Parent
{
    public void show(Object s)
    {
        System.out.println("Inside child method");
    }
    
    public Integer print() {
    	System.out.println("returning from child");
    	return 1;
    }
    
    public static void main(String[] args) {
    	
        Parent parent = new Child();
        parent.show("ABCD");
        parent.print();

    }

}
