package com.sape.decorator.design;

public interface Pizza {
	
	String descriotion();
	Double cost();

}
