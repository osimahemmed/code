package com.common;

public class TestStackOverFlow {
	int count = 0;
	
	 public void TestStackOverFlow1() {
		System.out.println(count);
		count ++;
		TestStackOverFlow1();
	}
	 
	 
	//TestStackOverFlow t1 = new TestStackOverFlow();

	public static void main(String[] args) {
		TestStackOverFlow t = new TestStackOverFlow();
		t.TestStackOverFlow1();
	}
}
