package com.java.concurrency.condition.api;

public class ProducerConsumerSolutionUsingConditionApi {

	public static void main(String[] args) {

		ProducerConsumerImpl prd = new ProducerConsumerImpl();
		
		Producer p = new Producer(prd);
		Consumer c = new Consumer(prd); 
		
		p.start();
		c.start();
		
	}

}
