package come.sape.stack.impl;

import java.util.Arrays;

public class CustomArrayList<E> implements ICustomList<E> {
	
	private static final int INTIAL_CAPACITY = 10;
	private int size = 0;
	private Object[] elementData = {};
	
	public CustomArrayList() {
		elementData = new Object[INTIAL_CAPACITY]; 
	}

	private void ensureCapacity() {
		int increaseCapacity = elementData.length * 2;
		elementData = Arrays.copyOf(elementData, increaseCapacity);
	}

	@Override
	public void add(E e) {
		if(size == elementData.length) {
			ensureCapacity();
		}
		elementData[size ++] = e;
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public E get(int index) {
		if(index < 0 || index >= size) {
			throw new ArrayIndexOutOfBoundsException("Index: " + index + " , Size " + size);
		}
		return (E) elementData[index];
	}

	@SuppressWarnings("unchecked")
	@Override
	public E remove(int index) {
		if(index < 0 || index >= size) {
			throw new ArrayIndexOutOfBoundsException("Index " + index + " , Size " + size);
		}
		
		E e = (E) elementData[index];
		for(int i = index; i < size -1; i++) {
			elementData[i] = elementData[i+1];
		}
		size --;
		
		return e;
		
	}
	
	public static void main(String[] args) {
		ICustomList<Integer> list = new CustomArrayList<>();
		for(int i = 1; i < 9; i++) {
			list.add(i);
		}
		
		int m = list.remove(2);
		System.out.println(m);
	}
}
