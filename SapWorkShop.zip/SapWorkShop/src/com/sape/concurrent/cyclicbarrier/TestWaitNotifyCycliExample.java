package com.sape.concurrent.cyclicbarrier;

public class TestWaitNotifyCycliExample {

    public static void main(String[] args) {

           Object firstLock = new Object();
           Object secondLock = new Object();
           Object thirdLock = new Object();
          // Object fourthLock = new Object();

           Object[] a1 = new Object[] { 1,4 };
           Object[] a2 = new Object[] { 2,5 };
           Object[] a3 = new Object[] { 3,6 };
          // Object[] a4 = new Object[] { 4, 8, 12, 16, 20 };

           Thread t1 = new Thread(new TestCycliceRunnable(a1, firstLock, secondLock));
           Thread t2 = new Thread(new TestCycliceRunnable(a2, secondLock, thirdLock));
           Thread t3 = new Thread(new TestCycliceRunnable(a3, thirdLock, firstLock));
           //Thread t4 = new Thread(new CycliceRunnable(a4, fourthLock, firstLock));
           
           t1.start();
           t2.start();
           t3.start();
          // t4.start();
           synchronized (firstLock) {
                  firstLock.notify();
           }
    }

}

class TestCycliceRunnable implements Runnable {
    final Object[] array;
    final Object waitLock;
    final Object notifyLock;

    public TestCycliceRunnable(Object[] array, Object waitLock, Object notifyLock) {
           this.waitLock = waitLock;
           this.notifyLock = notifyLock;
           this.array = array;
    }

    public void run() {
    	//System.out.println("Inside run " + Thread.currentThread().getName());
           try {
                  for (int i = 0; i < array.length; i++) {
                        synchronized (waitLock) {
                               waitLock.wait();
                        }
                      //  System.out.println("Inside run " + Thread.currentThread().getName());
                        System.out.println("Thread Name " + Thread.currentThread().getName() + " :: " + array[i]);
                        synchronized (notifyLock) {
                               notifyLock.notify();
                        }
                  }

           } catch (InterruptedException e) {
                  e.printStackTrace();
           }
    }
}

