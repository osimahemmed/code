package com.common;

public class ItestClass implements ITest,ITest1 {

	public static void main(String[] args) {
		
		//ItestClass obj = new ItestClass();
		ITest t = new ItestClass();
		t.test();
		//obj.test();
	}

	@Override
	public void test() {
		System.out.println("hello");
		
	}

}
