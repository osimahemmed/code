	package come.sape.stack.impl;

import java.util.ArrayList;
import java.util.EmptyStackException;
import java.util.List;

public class StackUsingArr<T> {
	
	private int index;
	private int size;
	private T [] arr;
	
	@SuppressWarnings("unchecked")
	public StackUsingArr(int size) {
		this.size = size;
		arr = (T[]) (new Object[size]);
		index = -1;
	}
	
	public boolean isFull() {
		return (index == size-1);
	}
	
	public boolean isEmpty() {
		return (index == -1);
	}
	
	public void push(T data) {
		if(isFull()) {
			throw new StackOverflowError("Array is full");
		}
		arr[++index] = (T)data;
	}
	
	public T pop() {
		if(isEmpty()) {
			throw new EmptyStackException();
		}
		return arr[index--];
		
	}
	
	public static void main(String[] args) {
		
		StackUsingArr<Integer> st = new StackUsingArr<>(2);
		st.push(10);
		st.push(20);
		int i1 = st.pop();
		int i2 = st.pop();
		//int s2 = st.pop();
		
		System.out.println(i1 +" " + i2);
		
		StackUsingArr<String> str = new StackUsingArr<>(3);
		str.push("osim");
		str.push("osim");
		str.push("osim");
		String s1 = str.pop();
		String s2 = str.pop();
		String s3 = str.pop();
		System.out.println(s1 +", " +s2 +", " +s3);
		//str.push("osim");
	}

}
