package com.sape.override;

import java.io.IOException;

public class TestOverrideObject {

    public static void main(String[] args) {
    	
        //Parent child = new Child();
        
        Child child = new Child();
        Parent p = child;
        child.show("ABCD");
       /* try {
			p.m1(10);
		} catch (IOException e) {
			e.printStackTrace();
		}*/

    }


}
