package com.sape.exception;

public class UserDefinedException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7422629369581871060L;
	
	public UserDefinedException(String excep) {
		super(excep);
	}

}
