package com.sape.design.command;

public class OpenFileCommand implements Command {
	
	FileSystemReceiver fileSystem;
	
	public OpenFileCommand(FileSystemReceiver fs) {
		this.fileSystem = fs;
	}
	
	@Override
	public void execute() {
		this.fileSystem.openFile();
		
	}

}
