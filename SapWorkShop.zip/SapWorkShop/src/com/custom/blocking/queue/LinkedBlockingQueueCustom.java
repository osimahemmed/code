package com.custom.blocking.queue;

import java.util.LinkedList;
import java.util.List;

public class LinkedBlockingQueueCustom<E> implements CustomBlockingQueue<E> {
	
	private List<E> queue;
	private int maxSize;
	
	public LinkedBlockingQueueCustom(int maxSize) {
		this.maxSize = maxSize;
		queue = new LinkedList<E>();
	}

	@Override
	public synchronized void put(E item) throws InterruptedException {
		if(queue.size() == maxSize) {
			System.out.println(" Queue is full "+Thread.currentThread().getName() + " is waiting");
			this.wait();
		}
		queue.add(item);
		this.notifyAll();
		
	}

	@Override
	public synchronized E take() throws InterruptedException {
		if(queue.isEmpty()) {
			System.out.println(" Queue is empty "+Thread.currentThread().getName() + " is waiting");
			this.wait();
		}
		this.notifyAll();
		return queue.remove(0);
	}
	
	public static void main(String[] args) throws InterruptedException {
		CustomBlockingQueue<Integer> b = new LinkedBlockingQueueCustom<>(10);
        /*BlockingQueueCustom<Integer> b=new LinkedBlockingQueueCustom<Integer>(10);
        System.out.println("put(11)");
        b.put(11);
        System.out.println("put(12)");
        b.put(12);
        System.out.println("take() > "+b.take());
        System.out.println("take() > "+b.take());*/
		
		Thread t1 = new Thread(new PutThread(b));
		Thread t2 = new Thread(new TakeThread(b));		
		t1.start();
		t2.start();
		
		/*b.put(10);
        b.put(34);
        b.put(40);
        b.put(40);
        b.put(40);
        b.put(40);
        b.put(40);
        b.put(40);
        b.put(40);
        b.put(40);
        b.put(40);
        b.put(40);
        b.put(40);
        System.out.println("take() > "+b.take());
        System.out.println("take() > "+b.take());
        System.out.println("take() > "+b.take());*/
        
        //Queue<Integer> q = new LinkedList<>();
    	
		
    }

}
