package com.sape.java.clone;

public class A {
	int i;
	public A(int i) {
		this.i = i;
	}
	
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
}
