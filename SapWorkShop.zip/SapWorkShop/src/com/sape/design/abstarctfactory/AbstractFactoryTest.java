package com.sape.design.abstarctfactory;

public class AbstractFactoryTest {

	public static void main(String[] args) {
		
		ICarFactory hondaCarFactory = FactoryProducer.getCarFactory("honda");
		ICar brio = hondaCarFactory.createCar("brio");
		brio.drive();
		
		ICar city = hondaCarFactory.createCar("city");
		city.drive();
		
		ICarFactory hyundaiCarFactory = FactoryProducer.getCarFactory("hyundai");
		ICar i10 = hyundaiCarFactory.createCar("i10");
		i10.drive();
		
		ICar i20 = hyundaiCarFactory.createCar("i20");
		i20.drive();
	}

}
