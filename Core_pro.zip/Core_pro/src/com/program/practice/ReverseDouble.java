package com.program.practice;

public class ReverseDouble {

	public static void main(String ...s)throws Exception{
		double d1 = 1234.6;
		double d2 = d1;
		int divider = getDivider(d1);
		while(d2 % 10 > 0){
			d2 = d2 * 10;
		}
		//System.out.println("divider="+divider);
		int i = (int)d2;
		int r = reverse(i);
		double d3 = r / (double)divider;
		System.out.println(d1);
		System.out.println(d3);

	}

	private static int getDivider(double d1) {
		int val = (int)d1;
		int divider = 1;
		while(val > 0){
			divider = divider * 10;
			val = val/10;
		}
		return divider;
	}

	private static int reverse(int i) {
		int s = 0;
		while(i > 0){
			s = s * 10 + i % 10;
			i = i / 10;
		}
		return s;
	}


}
