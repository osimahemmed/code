package com.java.countdown.deadlock;

public class MyDeadLock {

	public static void main(String[] args) {
		

	}

}
