package com.sape.decorator.design;

public abstract class PizzaTopping implements Pizza {
	Pizza pizza;
}
