/* 
 Input : 
        1
      /   \
     2     3
    / \   / \
   4   5 6   7
  /       \
 10        8
 
 */

package com.ds;

public class PrintLeafNodes {
	
	static class Node {
		int data;
		Node left, right;
		
		public Node(int data) {
			this.data = data;
			left = right = null;
		}
	}

	private static void printLeafNodes1(Node root) {
		if(root == null) {
			return;
		}
		if(root.left == null && root.right == null) {
			System.out.println(root.data);
		}
		printLeafNodes1(root.left);
		printLeafNodes1(root.right);
		
	}
	
	private static int sumOfAllNodes(Node root) {
		int sum = 0;
		if(root == null)
			return 0;
		sum = sum + root.data + sumOfAllNodes(root.left) + sumOfAllNodes(root.right);
		return sum;
	}
	
	static int sum = 0;
	private static int leafNodesSum(Node root) {
		if(root == null) {
			return 0;
		}
		if(root.left == null && root.right == null) {
			sum = sum + root.data;
		}
		leafNodesSum(root.left);
		leafNodesSum(root.right);
		return sum;
	}
	
	public static void main(String[] args) {
		Node root = new Node(1);
		root.left = new Node(2);
		root.right = new Node(3);
		root.left.left = new Node(4);
		root.left.right = new Node(5);
		root.right.left = new Node(6);
		root.right.right = new Node(7);
		root.right.left.right = new Node(8);
		root.left.left.left = new Node(10);
		
		printLeafNodes1(root);
		
		int sum = sumOfAllNodes(root);
		System.out.println("Total sum of all Nodes = " +sum);
		int leafNodeSum = leafNodesSum(root);
		
		System.out.println("leafNodeSum " + leafNodeSum);

	}

}
