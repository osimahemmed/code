package com.sape.override;

import java.io.IOException;

class Parent
{
   public void show(Object obj) throws NullPointerException
    
    {
        System.out.println("Inside parenet method " + obj);
    }
    
    public void show(String s)
    {
        System.out.println("Inside parent method of show" + s);
    }
    
   /* void m1(int i1) throws IOException {
    	System.out.println("in m1 of base " + i1);
    }*/
}

