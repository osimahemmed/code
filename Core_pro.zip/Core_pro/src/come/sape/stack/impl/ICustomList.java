package come.sape.stack.impl;

public interface ICustomList<E> {
	
	public void add(E e);
	public E get(int i);
	public E remove(int i);

}
