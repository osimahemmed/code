package com.sape.design.decorator;

public class SandWichMaker {

	public static void main(String[] args) {
		Sandwich mySandwich = new WhiteBreadSandWich("White bread sandwich");
		System.out.printf("Price of %s is $%.2f %n", 
				mySandwich.getDescription(),mySandwich.price());
		
		mySandwich = new CheeseDecorator(mySandwich);
		System.out.printf("Price of %s is $%.2f %n", mySandwich.getDescription(),
				mySandwich.price());

	}

}
