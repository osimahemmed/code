package com.design.factory;

public class Triangle implements IShape{

	@Override
	public void draw() {
		System.out.println("Drawing triangle");
	}
}
