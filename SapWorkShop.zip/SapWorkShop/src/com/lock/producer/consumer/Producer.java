package com.lock.producer.consumer;

import java.util.Queue;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class Producer extends Thread {
	
	private Lock lock;
	private Condition prdCon;
	private Condition conCon;
	private Queue<Integer> queue;
	final int size;
	
	public Producer(Lock lock, Condition prdCon, Condition conCon, Queue<Integer> queue, final int size){
		this.lock = lock;
		this.prdCon = prdCon;
		this.conCon = conCon;
		this.queue = queue;
		this.size = size;
	}

	@Override
	public void run() {
		for(int i = 0; i < 10; i++) {
			lock.lock();
			while(queue.size() == size) {
				try {
					prdCon.await();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			try {
				queue.add(i);
				System.out.println("Produced " + i);
				conCon.signal();
			} catch (IllegalStateException | IllegalMonitorStateException ex) {
				System.out.println(ex.getMessage());
			}
			finally {
				lock.unlock();
			}
			
		}
	}
}
