package com.mulitiple.prd.consumer;

public class BufferConsumer implements Runnable {

	Buffer buffer;
	public BufferConsumer(Buffer buffer) {
		this.buffer = buffer;
	}
	
	@Override
	public void run() {
		for (int i = 1; i <= 10; i++) {
			System.out.println("get : " + buffer.get());
		}
	}
}
