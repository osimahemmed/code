package com.custom.blocking.queue;

public class TakeThread implements Runnable {
	
	CustomBlockingQueue<Integer> custom1;
	public TakeThread(CustomBlockingQueue<Integer> custom1) {
		this.custom1 = custom1;
	}

	@Override
	public void run() {
		while(true) {
			try {
				int num = custom1.take();
				Thread.sleep(3000);
				if(num == -1) {
					break;
				}
				System.out.println("Getting nums " + num);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}

}
