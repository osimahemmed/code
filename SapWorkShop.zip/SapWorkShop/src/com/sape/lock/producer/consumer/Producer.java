package com.sape.lock.producer.consumer;

public class Producer extends Thread {
	
	ProducerConsumerImpl pc;
	
	public Producer(ProducerConsumerImpl pc) {
		super("PRODUCER");
		this.pc = pc;
	}
	@Override
	public void run() {
		try {
			pc.put();
		} catch (InterruptedException ie) {
			ie.printStackTrace();
		}
	}

}
