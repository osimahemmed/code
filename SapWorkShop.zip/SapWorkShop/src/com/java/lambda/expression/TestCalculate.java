package com.java.lambda.expression;

public class TestCalculate {

	public static void main(String[] args) {
		
		Calculate add = (a,b) -> a + b;
		Calculate diff = (a,b) -> Math.abs(a-b);
		Calculate multiply = (c,d) -> c*d;
		Calculate divide = (a,b) -> (b !=0 ? a/b : 0);
		System.out.println(add.calc(5,4));
		System.out.println(diff.calc(20, 5));
		System.out.println(multiply.calc(4, 6));
		System.out.println(divide.calc(12, 3));

	}

}
