package com.sape.ace.java8.palash;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ForEachExample {
	
	public static void main(String[] args) {
		List<Integer> deptIds = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9);
		
		
		
		
		
		biFunction();		
		evenStreamList();
		
	}

	/**
	 * 
	 */
	private static void biFunction() {
		Map<Integer, String> map = new HashMap<>();
		
		map.put(1, "a");
		map.put(2, "b");
		map.put(3, "c");
		map.put(4, "d");
		map.put(5, "e");
		 
		map.forEach((key, value) -> {
			System.out.println(key +" | " + value);
		});
	}

	/**
	 * 
	 */
	private static void evenStreamList() {
		List<Integer> nums = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9);
		List<Integer> numsList = nums.stream().filter((Integer num) -> {
			return num % 2 == 0;
		}).collect(Collectors.toList());
		
		System.out.println(numsList);
	}

	/**
	 * 
	 */
	private static void forEach() {
		List<String> list = Arrays.asList("a","b","c","d","e");
		
		List<Employee> empList = list.stream().map(name -> {
			System.out.println("******" + name);
			Employee emp = lookup(name);
			return emp;
		}).collect(Collectors.toList());
	System.out.println(empList);
	}
	
	
	private static Employee lookup (String name) {
		return new Employee();
	}
	
	private static class Employee {
		String id;
		String name;
	}

	private static class Department {
		private int id;
		private String name;
		private List<Employee> listEmp;
	}
}
