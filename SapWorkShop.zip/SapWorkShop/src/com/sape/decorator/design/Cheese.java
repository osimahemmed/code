package com.sape.decorator.design;

public class Cheese extends PizzaTopping {
	
	public Cheese(Pizza pizza) {
		this.pizza  = pizza;
	}

	@Override
	public String descriotion() {
		return "Cheese";
	}

	@Override
	public Double cost() {
		return pizza.cost() + 2.0;
	}

}
