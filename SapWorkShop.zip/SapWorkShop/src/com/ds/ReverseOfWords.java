package com.ds;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class ReverseOfWords {
	
	public static void main(String[] args) {
		
		Map<String, String> map = new HashMap<String, String>();
		Collections.synchronizedMap(map);
		
		String words = "Hello welcome to sapient";
		reverseWords(words);

	}

	private static void reverseWords(String words) {
		
		String[] tempArr = words.split("\\s");
		String result = "";
		 
		for(int i = 0; i < tempArr.length; i++) {
			if(i == tempArr.length-1) {
				result = tempArr[i] + result;
			} else {
				result = " " + tempArr[i] + result;
			}
		}
		System.out.println(result);
		
	}
}
