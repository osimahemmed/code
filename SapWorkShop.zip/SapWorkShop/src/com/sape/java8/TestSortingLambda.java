package com.sape.java8;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class TestSortingLambda {

	public static void main(String[] args) {
		
		List<Developer> listDevs = getDevelopers();
		System.out.println("Before Sort");
		for(Developer developer : listDevs) {
			System.out.println(developer);
		}
		System.out.println("After Sort");
		//listDevs.sort((o1, o2)->o1.getAge()-o2.getAge());//sort by age
		//listDevs.sort((o1, o2)->o1.getName().compareTo(o2.getName()));//sort by name
		listDevs.sort((o1, o2)-> o1.getSalary().compareTo(o2.getSalary()));//sort by salary
		
		Comparator<Developer> salaryComparator = (o1, o2)-> o1.getSalary().compareTo(o2.getSalary());
		//listDevs.stream().filter(d -> d.getSalary() >= 50).forEach(System.out::println));
		Comparator<Developer>  nameComp = (n1, n2) -> n1.getName().compareTo(n2.getName());
		
		listDevs.sort(salaryComparator.reversed());//reversed sorted
		listDevs.forEach((developer)->System.out.println(developer));

	}
	
	private static List<Developer> getDevelopers() {

		List<Developer> result = new ArrayList<Developer>();

		result.add(new Developer("mkyong", new BigDecimal("100000"), 33));
		result.add(new Developer("alvin", new BigDecimal("170000"), 20));
		result.add(new Developer("jason", new BigDecimal("7000"), 10));
		result.add(new Developer("iris", new BigDecimal("80000"), 55));

		return result;

	}

}
