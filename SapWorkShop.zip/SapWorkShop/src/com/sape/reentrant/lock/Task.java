package com.sape.reentrant.lock;

public interface Task {
	
	void performTask();

}
