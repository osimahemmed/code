package com.sape.static1.test;

public class MainStaticTest {

	public static void main(String[] args) {
		
		AStatic st = new ChildStatic();
		AStatic st1 = new ChildStatic();

	}

}
