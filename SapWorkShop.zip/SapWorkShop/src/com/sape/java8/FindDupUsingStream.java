package com.sape.java8;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class FindDupUsingStream {

	public static void main(String[] args) {
		
		String str;
		List<Integer> list = Arrays.asList(new Integer[]{1, 2, 1, 2, 5, 2, 7, 4, 5, 4});
		list.stream().distinct().forEach(System.out::println);
		
		List<Integer> uniqueList = list.stream().distinct().collect(Collectors.toList());
		System.out.println("unique list " + uniqueList);
		
		Set<Integer> dupList1 = list.stream().filter(j -> Collections.frequency(list, j) > 1).collect(Collectors.toSet());
		
		System.out.println("osim ** " + dupList1);
		
		list.stream().filter(i -> Collections.frequency(list, i) > 1)
			.collect(Collectors.toSet()).forEach(System.out::println);
		
		list.stream().filter(j -> Collections.frequency(list, j) > 1).collect(Collectors.toSet()).forEach(System.out::println);
		
		Set<Integer> dupList = list.stream().filter(i -> Collections.frequency(list, i) > 1)
				.collect(Collectors.toSet());
		
		System.out.println(" osim "+dupList);
		
		
		Integer[] numbers = new Integer[] { 1, 2, 1, 3, 4, 4 };
		
		Set<Integer> allItems = new HashSet<>();
		Set<Integer> duplicates = Arrays.stream(numbers)
		        .filter(n -> !allItems.add(n)) //Set.add() returns false if the item was already in the set.
		        .collect(Collectors.toSet());
		System.out.println(duplicates); // [1, 4]
		
		//sort list
		
		List<Integer> sortList = Arrays.asList(numbers);
		//sortList.sort((p1, p2) -> p1.compareTo(p2) );
		//System.out.println(sortList);
		sortList.sort((p1,p2) -> p1.compareTo(p2));
		System.out.println(sortList);

	}

}
