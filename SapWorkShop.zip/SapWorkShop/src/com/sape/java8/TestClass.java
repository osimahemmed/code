package com.sape.java8;

public class TestClass implements TestInterface1, TestInterface2 {

	public void show() {
		/*TestInterface1.super.show();
		TestInterface2.super.show();*/
		System.out.println("show of main class");
	}
	public static void main(String[] args) {
		TestClass td = new TestClass();
		td.show();

	}

}
