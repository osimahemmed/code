package com.java.lambda.expression;

@FunctionalInterface
public interface Calculate {
	int calc(int x, int y);
}
