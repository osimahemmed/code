package com.sape.java.clone;

class B implements Cloneable {
	
	int j;
	A a;
	
	public B(int j, A a) {
		this.j = j;
		this.a = a;
	}
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		//return super.clone();
		B b = (B) super.clone();
		b.a = (A) a.clone();
		return b;
	}
	
	public static void main(String[] args) throws CloneNotSupportedException {
		
		A a = new A(10);
		B b1 = new B(30, a);
		B b2 = null;
		
		try {
			b2 = (B) b1.clone();
		} catch (CloneNotSupportedException e) {
			
		}
		
		System.out.println(b1.a.i);
		b2.a.i = 200;
		
		System.out.println(b1.a.i);
		/*B b  = new B();
		b.i = 10;
		b.j = 20;
		
		B b2 = (B) b.clone();
		b2.i = 30;
		b2.j = 50;
		System.out.println(b.i);
		System.out.println(b.j);
		
		System.out.println(b == b2);*/
		
	}
	
}
