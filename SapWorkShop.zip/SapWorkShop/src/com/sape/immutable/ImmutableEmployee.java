package com.sape.immutable;

public class ImmutableEmployee {

	private final int id;
	private final Address address_1;
	
	public ImmutableEmployee(int id, Address address)
	{
		this.id = id;
		this.address_1 = new Address();  // defensive copy
		//this.address_1.setStreet( address.getStreet() );
	}
	
	public int getId() {
		return id;
	}
	public Address getAddress() {
		Address new_address = new Address(); // must copy here too
		new_address.setStreet( this.address_1.getStreet() );
		return new_address;

	}
}
