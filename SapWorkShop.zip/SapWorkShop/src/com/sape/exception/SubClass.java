package com.sape.exception;

class SubClass extends SuperClass{
    void method() throws NullPointerException{
           System.out.println("SubClass method");
    }
}
