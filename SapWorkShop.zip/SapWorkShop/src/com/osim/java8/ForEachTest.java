package com.osim.java8;

import java.util.ArrayList;
import java.util.List;

public class ForEachTest {

	public static void main(String[] args) {
		
		List<String> names = new ArrayList<String>();
		
	      names.add("Maggie");
	      names.add("Michonne");
	      names.add("Rick");
	      names.add("Merle");
	      names.add("Governor");
	      
	      names.stream()
	      .filter(s -> s.startsWith("M"))
	     // .parallel()
	      .forEach(System.out::println);

	}

}
