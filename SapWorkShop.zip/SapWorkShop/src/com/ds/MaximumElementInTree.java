package com.ds;

import java.util.Queue;

public class MaximumElementInTree {
	
	static class Node {
		int data;
		Node left, right;
		
		public Node(int data) {
			this.data = data;
			left = right = null;
		}
	}
	
	private static int findMaxElement(Node root) {
		if (root == null)
			return 0;
		Queue<Node> queue = new java.util.LinkedList<>();
		queue.add(root);
		int max = Integer.MIN_VALUE;
		while(!queue.isEmpty()) {
			Node temp = queue.poll();
			if(max < temp.data) {
				max = temp.data;
			}
			if(temp.left != null) {
				queue.add(temp.left);
			}
			if(temp.right != null) {
				queue.add(temp.right);
			}
		}
		return max;
	}
	
	private static int getMaximumRec(Node root) {
		
		int max=Integer.MIN_VALUE;
		int value=0;
		int left,right;
		if(root != null)  
		{
			value=root.data;
			left=getMaximumRec(root.left);
			right=getMaximumRec(root.right);
 
			if(left>right)
			{
				max=left;
			}
			else
			{
				max=right;
			}
 
			if(max < value)
			{
				max=value;
			}
		}
 
		return max;
		
	}

	public static void main(String[] args) {
		Node root = new Node(40);
		root.left = new Node(20);
		root.right = new Node(60);
		root.left.left = new Node(10);
		root.left.right = new Node(30);
		root.right.left = new Node(50);
		root.right.right = new Node(70);
		
		int max = findMaxElement(root);
		System.out.println("Max is " + max);
		
		System.out.println("Max node using recursion :"+getMaximumRec(root));

	}

}
