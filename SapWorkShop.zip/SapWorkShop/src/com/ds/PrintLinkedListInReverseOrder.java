package com.ds;

public class PrintLinkedListInReverseOrder {
	
	static Node head;
	static class Node {
		int data;
		Node next;
		public Node(int data) {
			this.data = data;
			next = null;
		}
	}
	
	Node curr = null;
	private void push(int new_data) {
		
		Node new_node = new Node(new_data);
		
		if(head == null) {
			head = new_node;
			curr = head;
		} else {
			curr.next = new_node;
			curr = curr.next;
		}
	}
	
	
	private void printList() {
		while(head != null) {
			System.out.println(head.data);
			head = head.next;
		}
	}
	
	private void printReverse(Node head) {
		while(head == null) {
			return;
		}
		printReverse(head.next);
		System.out.printf("%d ", head.data);
	}
	
	private void printReverse1(Node head) {
		while(head == null)
			return;
		printReverse1(head.next);
		System.out.printf("%d " , head.data);
	}

	public static void main(String[] args) {
		int[] data = {1, 2, 3, 4 ,5 ,6, 7};
		//Node head = new Node(data[0]);
		PrintLinkedListInReverseOrder obj = new PrintLinkedListInReverseOrder();
		obj.push(1);
		obj.push(2);
		obj.push(3);
		obj.push(4);
		/*for(int count = 0; count < data.length; count ++) {
			obj.push(data[count]);
		}*/
		
		//obj.printList();
		obj.printReverse(head);
		System.out.println();
		obj.printList();
		//new PrintLinkedListInReverseOrder().printList();
		

	}

}
