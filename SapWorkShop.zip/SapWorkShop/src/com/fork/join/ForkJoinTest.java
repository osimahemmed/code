package com.fork.join;

import java.util.concurrent.ForkJoinPool;

public class ForkJoinTest {

    static ForkJoinPool forkJoinPool = new ForkJoinPool();
    
    
    public static final int LENGTH = 1000000;
    public static void main(String[] args) {
        int [] numbers = new int[LENGTH];
        for(int i=0; i<LENGTH; i++){
            numbers[i] = i;
        }
        
        /*
         * Invoke the NumberDividerTask with the array
         * which in turn creates multiple sub tasks.
         */
        int sum = forkJoinPool.invoke(new NumberDividerTask(numbers));
      
        System.out.println("Sum: "+sum);
    }
}

