package com.bc.junit;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.abc.test.MyClass;

public class MyTests {
	@Test
	public void mytest() {
		MyClass cla = new MyClass();
		assertEquals("10 * 0 must be zero",0,cla.multiply(5, 0));
		
	}

}
