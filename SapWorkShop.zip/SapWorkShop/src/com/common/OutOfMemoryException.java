package com.common;

public class OutOfMemoryException {

	public static void main(String[] args) {
		
		try {
			m1();
		} catch (OutOfMemoryError e) {
			System.out.println("Catching out of memory exception " + e.getMessage());
		}

	}
	
	public static void m1() throws OutOfMemoryError {
		int[] arr = new int[Integer.MAX_VALUE];
	}

}
