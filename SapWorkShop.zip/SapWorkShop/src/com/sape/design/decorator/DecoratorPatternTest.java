package com.sape.design.decorator;

public class DecoratorPatternTest {

	public static void main(String[] args) {
		Car sportsCar = new SportsCar(new BasicCar());
		sportsCar.assemble();
		
		System.out.println("\n*****");
		Car luxurycar = new LuxuryCar(new BasicCar());
		luxurycar.assemble();
	}

}
