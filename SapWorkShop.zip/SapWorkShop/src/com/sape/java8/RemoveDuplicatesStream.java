package com.sape.java8;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class RemoveDuplicatesStream {

	public static void main(String[] args) {
		
		ConcurrentHashMap<String, String> map = new ConcurrentHashMap<>();
		map.put("", "");
		
		List<Department> deptList = new ArrayList<Department>();
        deptList.add(new Department(1, "IT"));
        deptList.add(new Department(2, "HR"));
        deptList.add(new Department(1, "IT"));
        deptList.add(new Department(4, "Development"));
        deptList.add(new Department(2, "HR"));

        Set<String> deptSet = new HashSet<String>();
        
        deptList.removeIf(p -> !deptSet.add(p.getDeptName()));
        
        deptList.forEach(dept -> System.out.println(dept.getDeptId() + " : " + dept.getDeptName()));
	}

}
