package com.sape.ace.java8.palash;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FlatMapStudent {

	public static void main(String[] args) {
		List<Student> studentList = new ArrayList<>();
		studentList.add(new Student("Joe", "A", "geography", "math","history"));
		studentList.add(new Student("Thomas", "B", "datastructure","history"));
		studentList.add(new Student("Bibhu", "C", "science"));
		

	}

	private static class Student {
		private String name;
		private String grade;
		private List<String> courses;
		
		public Student(String name, String grade, String... course) {
			this.name = name;
			this.grade = grade;
			this.courses = Arrays.asList(course);
		}
		
		public List<String> getCourses() {
			return courses;
		}
	}
}
