package com.sape.lock.custom;

public interface ICustomLock {
	void lock();
	void unlock();
	boolean tryLock();

}
