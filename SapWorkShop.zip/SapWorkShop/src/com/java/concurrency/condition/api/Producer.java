package com.java.concurrency.condition.api;

public class Producer extends Thread {
	ProducerConsumerImpl pc;
	
	public Producer(ProducerConsumerImpl pc) {
		super("Producer");
		this.pc = pc;
	}
	
	@Override
	public void run() {
		try {
			pc.put();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
