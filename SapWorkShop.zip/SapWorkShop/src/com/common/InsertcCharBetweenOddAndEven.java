package com.common;

public class InsertcCharBetweenOddAndEven {

	public static void main(String[] args) {
		
		//InputStreamReader reader = new InputStreamReader(System.in);
		//BufferedReader bfReader = new BufferedReader(reader);
		//String line = bfReader.readLine();
	    StringBuilder sb = new StringBuilder();
		String line ="624875";
		sb.append(line.charAt(0));
		for(int i = 1; i < line.length(); i++) {
			if(line.charAt(i)%2 == 0 && line.charAt(i-1)%2 == 0) {
				sb.append("*"+line.charAt(i));
			}else if(line.charAt(i)%2 != 0 && line.charAt(i-1)%2 != 0) {
				sb.append("-"+line.charAt(i));
			}
			else {
				sb.append(line.charAt(i));
			}
		}
		System.out.println(sb.toString());

	}

}
