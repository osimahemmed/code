package com.sape.reentrant.lock;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main {

	public static void main(String[] args) {
		final int nThreads = 5;
		final ExecutorService service = Executors.newFixedThreadPool(nThreads);
		final Task  task = new LockUnlockDemo();
		for(int i=0;i<nThreads;i++) {
			service.execute(new Worker(task));
		}
		
		service.shutdown();
	}

}
