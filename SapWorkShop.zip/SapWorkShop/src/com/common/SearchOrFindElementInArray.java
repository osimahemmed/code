package com.common;

public class SearchOrFindElementInArray {

	public static void main(String[] args) {
		int[] arr = {3, 5, 1, 4, 7, 10, 2, 11, 56};
		int len = arr.length;
		
		boolean b =  search(arr, len, 7);
		System.out.println(b);

	}
	
	private static boolean search(int[] arr, int len, int k ) {
		
		for(int i = 0; i < len-1/2; i++ ) {
			if(arr[i] == k || 
				arr[len-i-1] == k) {
				return true;
			}
		}
		/*for(int i = 0 ; i < len-1; i++) {
			if(arr[i] == k) {
				return true;
			}
		}*/
		return false;
		
	}

}
