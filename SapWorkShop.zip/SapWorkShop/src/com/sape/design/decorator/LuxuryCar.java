package com.sape.design.decorator;

public class LuxuryCar extends CarDecorartor {

	public LuxuryCar(Car c) {
		super(c);
	}
	
	public void assemble() {
		super.assemble();
		System.out.println("Adding fucntionalities for Luxury Car");
	}
}
