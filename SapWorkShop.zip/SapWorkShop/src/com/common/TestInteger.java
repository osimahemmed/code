package com.common;

public class TestInteger {

	public static void main(String[] args) {
		
		Integer a = new Integer(5);
		Integer b = new Integer(5);
		
		System.out.println(a == b);

	}

}
