package com.ds;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class SecondMostRepeatingChar {

	public static void main(String[] args) {
		
		//String str = "aabababa";
		//String str = "geeksforgeeks";
		//String str = "abcd";
		String str = "geeksquiz";
		Character a = find(str);
		System.out.println(a);

	}
	
	//public static int find(int[] numbers) {
	public static Character find(String str) {
		
		//int secondMostRepeating = 0;
	    Character secondMostRepeating= '\0';
		Map<Character, Integer> mp = new HashMap<Character, Integer>();
		int count = 1;
		for (int i = 0; i < str.length(); i++) {
			if (mp.containsKey(str.charAt(i))) {
				count = mp.get(str.charAt(i));
				mp.put(str.charAt(i), ++count);
			} else {
				mp.put(str.charAt(i), 1);
			}
		}
		int max = Integer.MIN_VALUE;
		int second = Integer.MIN_VALUE;
		Set<Entry<Character, Integer>> set = mp.entrySet();
		for (Entry<Character, Integer> entry : set) {
			if (entry.getValue() >= max) {
				max = entry.getValue();
			} else if (entry.getValue() >= second) {
				second = entry.getValue();
				secondMostRepeating = entry.getKey();
			}
		}
		return secondMostRepeating;
	}
}
