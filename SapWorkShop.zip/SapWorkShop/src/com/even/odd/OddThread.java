package com.even.odd;

public class OddThread implements Runnable {
	
	Object mutex;
	public OddThread(Object mutex) {
		this.mutex = mutex;
	}

	@Override
	public void run() {
		for(int i = 1;i < 10; i = i+2) {
			synchronized (mutex) {
				while(!EvenOdd.printFlag) {
					try {
						mutex.wait(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				System.out.println(i);
				EvenOdd.printFlag = !EvenOdd.printFlag;
				//mutex.notifyAll();
			}
		}
		
	}

}
