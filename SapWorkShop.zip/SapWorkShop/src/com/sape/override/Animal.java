package com.sape.override;

public class Animal {
	 
    public void eat() {
        System.out.println("eat from animal");
    }
}
