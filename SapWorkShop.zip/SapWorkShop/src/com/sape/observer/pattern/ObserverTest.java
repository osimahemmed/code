package com.sape.observer.pattern;

public class ObserverTest {

	public static void main(String[] args) {
		
		Customer customer1 = new Customer();
		customer1.setCustomerName("Izaan");
		
		Customer customer2 = new Customer();
		customer2.setCustomerName("Affan");
		
		Product product = new Product();
		product.setProductName("Apple IPhone 6");
		product.setAvailable(false);//out of stock as the argument is false
		//make sure both customers register for notifications
		product.registerObserver(customer1);
		product.registerObserver(customer2);
		
		//after few days phone is available
		product.setAvailable(true);
		//customer2 wants to unregister for phone as he purchased from other site
		product.removeObserver(customer2);
		product.setAvailable(true);

	}

}
