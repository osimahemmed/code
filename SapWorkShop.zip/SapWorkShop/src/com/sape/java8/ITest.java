package com.sape.java8;

public interface ITest {
	
	default void defaultMethod1() {
		System.out.println("default method of Interface ITest");
	}
	
}
