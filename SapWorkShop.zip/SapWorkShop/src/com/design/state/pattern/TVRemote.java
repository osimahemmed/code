package com.design.state.pattern;

public class TVRemote {

	public static void main(String[] args) {
		
		TVContext context = new TVContext();
		
		State startState = new TVStartState();
		State stopState = new TVStopState();
		
		context.setState(startState);
		context.doAction();
		
		context.setState(stopState);
		context.doAction();
	}

}
