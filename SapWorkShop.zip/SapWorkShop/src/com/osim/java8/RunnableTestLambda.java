package com.osim.java8;

public class RunnableTestLambda {

	public static void main(String[] args) {
		
		Runnable task1 = () -> {System.out.println("running task1");};
		
		new Thread(task1).start();

	}

}
