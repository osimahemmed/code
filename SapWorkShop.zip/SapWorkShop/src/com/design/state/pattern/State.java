package com.design.state.pattern;

public interface State {
	void doAction();
}
