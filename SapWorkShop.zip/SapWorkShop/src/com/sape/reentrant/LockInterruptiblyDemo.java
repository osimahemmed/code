package com.sape.reentrant;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class LockInterruptiblyDemo implements Task {
	final Lock reentrantLock = new ReentrantLock();
	@Override
	public void performTask() {
	     try {
		   reentrantLock.lockInterruptibly();
		   //if it is not able to acquire lock because of other threads interrupts,
		   //it will throw InterruptedException and control will go to catch block.
		   try {
				System.out.println(Thread.currentThread().getName() +": Lock acquired.");
				System.out.println("Work on progress...");
			        Thread.sleep(2000);	
		   } finally {
				System.out.println(Thread.currentThread().getName() +": Lock released.");
				reentrantLock.unlock();
		   }
	     } catch (InterruptedException e) {
		   e.printStackTrace();
	     }
	}
} 

/*
Change the line in Main class as follows and run it.
final Task task = new LockInterruptiblyDemo();
*/