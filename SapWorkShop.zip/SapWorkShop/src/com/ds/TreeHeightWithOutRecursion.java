package com.ds;

import java.util.Queue;

public class TreeHeightWithOutRecursion {
	
	static class Node {
		int data;
		Node left, right;
		
		public Node(int data) {
			this.data = data;
			left = right = null;
		}
	}

	private static int getHeight(Node root) {
		if (root == null)
			return 0;
		
		return Math.max(getHeight(root.left), getHeight(root.right))+1 ;
		
	}
	private static int getHeightIterative(Node root) {
		
		int height = 0;
		Queue<Node> queue = new java.util.LinkedList<>();
		queue.add(root);
		queue.add(null);
		
		while(!queue.isEmpty()) {
			Node temp = queue.poll();
			if(temp == null) {
				if(!queue.isEmpty()) {
					queue.add(null);
				}
				height ++;
			} else {
				if(temp.left != null) {
					queue.add(temp.left);
				}
				if(temp.right != null) {
					queue.add(temp.right);
				}
			}
		}
		
		return height;
		
	}
	public static void main(String[] args) {
		
		Node root = new Node(10);
		root.left = new Node(5);
		root.right = new Node(20);
		root.left.left = new Node(3);
		root.left.right = new Node(4);
		root.right.left = new Node(23);
		root.right.right = new Node(34);
		root.right.left.left = new Node(45);
		root.right.left.right = new Node(47);
		
		System.out.println("Height is " + getHeight(root));
		System.out.println("**** " +getHeightIterative(root));
		//getHeight(root);

	}

}
