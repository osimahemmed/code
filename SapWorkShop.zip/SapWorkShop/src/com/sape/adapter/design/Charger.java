package com.sape.adapter.design;

public interface Charger {
	
	public void setMobileName(String mobileName);
	public void supplyCharge();
}
