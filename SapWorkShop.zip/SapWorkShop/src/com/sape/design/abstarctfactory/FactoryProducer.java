package com.sape.design.abstarctfactory;

public class FactoryProducer {

	public static ICarFactory getCarFactory(String factoryType) {
		if("hyundai".equalsIgnoreCase(factoryType)) {
			return new HyundaicarFactory();
		}
		if("honda".equalsIgnoreCase(factoryType)) {
			return new HondaCarfactory();
		}
		
		return null;
	}
}
