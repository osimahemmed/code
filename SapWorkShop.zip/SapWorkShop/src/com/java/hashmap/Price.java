package com.java.hashmap;

class Price{
    
    private String item;
    private int price;
     
    public Price(String itm, int pr){
        this.item = itm;
        this.price = pr;
    }
     
    public int hashCode(){
       
        return 3;
    }
     
    /*public boolean equals(Object obj){
        
        if (getClass() == Price.class) {
        	//System.out.println("In equals " + getClass());
            Price pr = (Price) obj;
            return (pp.item.equals(this.item) && pp.price == this.price);
        } else {
            return false;
        }
    }*/
    
    public boolean equals(Object obj) {
    	if(getClass() == Price.class ) {
    		System.out.println("In equals " + getClass());
    		Price pr = (Price)obj;
    		return (pr.item.equals(this.item) && pr.price == this.price);
    	} else {
    		return false;
    	}
    }
     
    public String getItem() {
        return item;
    }
    public void setItem(String item) {
        this.item = item;
    }
    public int getPrice() {
        return price;
    }
    public void setPrice(int price) {
        this.price = price;
    }
     
    public String toString(){
        return "item: "+item+"  price: "+price;
    }
}
