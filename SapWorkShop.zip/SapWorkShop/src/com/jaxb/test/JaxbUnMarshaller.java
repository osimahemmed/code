package com.jaxb.test;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

public class JaxbUnMarshaller {

	public static void main(String[] args) {
		File file = new File("D:\\customer100.xml");
		try {
			JAXBContext context = JAXBContext.newInstance(Customer.class);
			Unmarshaller jaxbUnmarshaller = context.createUnmarshaller();
			Customer customer = (Customer) jaxbUnmarshaller.unmarshal(file);
			System.out.println(customer);
			
		} catch (JAXBException e) {
			e.printStackTrace();
		}
	}

}
