package com.common;

public class A {
	public int a = 5;
	
	public static void sayHello() {
		System.out.println("Super class A");
	}
	
	/*public void m1(int a, int b) {
		System.out.println("ab" +a);
	}
	public void m1(int a, String b) {
		System.out.println("ab" +b);
	}

	public static void main(String[] args) {
		A a = new A();
		a.m2(2, 3);
	}*/
}