package com.sape.ds.practice;

import java.util.Stack;

public class QueueUsingStack {
	
	Stack<Integer> stack1 = new Stack<>();
	Stack<Integer> stack2 = new Stack<>();
	
	public void push(int x) {
		stack1.push(x);
	}

	public int peek() {
		System.out.println("stack1 "+ stack1);
		if(stack2.isEmpty()) {
			moveElements(stack1, stack2);
		}
		System.out.println("stack2" + stack2);
		return stack2.peek();
	}
	
	public int pop() {
		if(stack2.isEmpty()) {
			moveElements(stack1, stack2);
		}
		return stack2.pop();
	}
	
	public void moveElements(Stack<Integer> stack1, Stack<Integer> stack2) {
		while(!stack1.isEmpty()) {
			stack2.push(stack1.pop());
		}
	}
	
	public static void main(String[] args) {
		QueueUsingStack s = new QueueUsingStack();
		s.push(4);
		s.push(1);
		s.push(3);
		//s.pop();
		System.out.println(s.peek());
		
		System.out.println(s.stack2);

	}

}
