package com.sape.java8;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ForEachTest {

	public static void main(String[] args) {
		
		List<String> items = new ArrayList<>();
		items.add("A");
		items.add("B");
		items.add("E");
		items.add("D");
		items.add("C");
		
		items.forEach(item->System.out.println(item));
		items.forEach(System.out::println);
		
		items.forEach(item-> {
			if("C".equals(item)) {
				System.out.println("matching item " +item);
			}
		});
		
		//Stream and filter
		//Output : B
		items.stream()
			.filter(s->s.contains("B"))
			.forEach(System.out::println);
		
		
		Map<String, Integer> itemMap = new HashMap<>();
		itemMap.put("A", 10);
		itemMap.put("B", 20);
		itemMap.put("C", 30);
		itemMap.put("D", 40);
		itemMap.put("E", 50);
		itemMap.put("F", 60);

		for (Map.Entry<String, Integer> entry : itemMap.entrySet()) {
			System.out.println("Item : " + entry.getKey() + " Count : " + entry.getValue());
		}
		
		System.out.println("Using java 8");
		
		itemMap.forEach((k,v)->System.out.println("Item : " + k + " Count : " + v));
		
		itemMap.forEach((k,v)->{
			System.out.println("Item : " + k + " Count : " + v);
			if("E".equals(k)) {
				System.out.println("Hello E");
				itemMap.put("K", 100);
			}
		});
	}

}
