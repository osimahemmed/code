package com.ds;

public class RemoveDuplicatesInSortedLinkedList {
	
	Node head;
	class Node {
		int data;
		Node next;
		public Node(int data) {
			this.data = data;
		}
	}
	
	Node curr = null;
	private void push(int new_data) {
		Node new_node = new Node(new_data);
		if(head == null) {
			head = new_node;
			curr = head;
		} else {
			curr.next = new_node;
			curr = curr.next;
		}
	}

	private void printList(Node head) {
		while(head != null) {
			System.out.printf(" %d " , head.data);
			head = head.next;
		}
	}
	
	private Node sort(Node head) {
		if(head == null)
			return null;
		Node current = head;
		while(current.next != null) {
			if(current.data == current.next.data) {
				Node temp = current.next.next;//1 1 3 4
				current.next = temp;
			} else {
				current = current.next;
			}
		}
		return head;
	}
	
	public static void main(String[] args) {
		RemoveDuplicatesInSortedLinkedList li = new RemoveDuplicatesInSortedLinkedList();
		li.push(1);
		li.push(2);
		li.push(2);
		li.push(3);
		li.push(3);
		li.push(4);
		System.out.println("Before sorting ");
		li.printList(li.head);
		Node nod  = li.sort(li.head);
		//li.sort(nod);
		System.out.println( "\n" +"After sorting");
		li.printList(nod);

	}

}
