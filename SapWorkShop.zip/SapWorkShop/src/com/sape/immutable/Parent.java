package com.sape.immutable;

public class Parent {
	
	/*int m1() {
		System.out.println("Parent called");
		return 1; 
	}*/
	
	int m1(Object a) {
		System.out.println("Parent m1");
		return 3;
	}

}
