package com.common;

import java.util.Scanner;


public class UserInputMain {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		String str = scanner.next();

		/*String str = scanner.nextLine();
		String str1 = scanner.nextLine();
		String str2 = scanner.nextLine();
		//String str3 = scanner.nextLine();
		System.out.println(str);
		System.out.println(str1);
		System.out.println(str2);*/

		int myInt = scanner.nextInt();

		Double db = scanner.nextDouble();

		scanner.close();

		System.out.println("myString is: " + str);
		System.out.println("myInt is: " +myInt);
		System.out.println("myInt is: " +db);
	}
}
