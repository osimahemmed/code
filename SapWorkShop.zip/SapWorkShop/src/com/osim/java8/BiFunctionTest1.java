package com.osim.java8;

import java.util.function.BiFunction;
import java.util.function.Function;

public class BiFunctionTest1 {

	public static void main(String[] args) {
		
		//Function<String, Integer> f1 = str -> str.length();
		Function<String, Integer> f1 = str -> str.length();
        int len = f1.apply("TopJavaTutorial");
        System.out.println(len);
       

	}

}
