/*
 * One line answer: flatMap helps to flatten a Collection<Collection<T>> into a Collection<T>. 
 * In the same way, it will also flatten an Optional<Optional<T>> into Optional<T>.
 * 
 * As you can see, with map() only:

	The intermediate type is Stream<List<Item>>
		The return type is List<List<Item>>
	
	and with flatMap():
	
		The intermediate type is Stream<Item>
		The return type is List<Item>
 */


package com.sape.ace.java8.palash;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

public class FlatMapExample {

	public static void main(String[] args) {
		
		Parcel amazon = new Parcel("amazon", "Laptop", "Phone");
		Parcel ebay = new Parcel("ebay", "Mouse", "Keyboard");
	    
		List<Parcel> parcels = Arrays.asList(amazon, ebay);
	    
	    System.out.println("Without flat map");
	    
	    List<List<String>> list = parcels
	    		.stream()
	    		.map(Parcel::getItems)
	    		.collect(Collectors.toList());
	    
	    System.out.println(list);

	    System.out.println("\n-------- With flatMap() ------------------------------");
	    
	    List<String> mapFlat= parcels.stream()
	    		.map(Parcel::getItems)
	    		.flatMap(Collection::stream)
	    		.collect(Collectors.toList());
	    
	    System.out.println(mapFlat);
	    
	}
	
	
	private static class Parcel {
		private String name;
		private List<String> items;
		
		public Parcel(String name, String... items) {
			this.name = name;
			this.items = Arrays.asList(items);
		}
		
		public List<String> getItems() {
			return items;
		}
		
		@SuppressWarnings("unused")
		public String getName() {
			return name;
		}
	}
	

}


