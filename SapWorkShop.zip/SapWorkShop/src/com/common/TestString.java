package com.common;

public class TestString {

	public static void main(String[] args) {
		
		String s = "osim";
			   s = "ahemmed";
		
		System.out.println(s);

	}

}
