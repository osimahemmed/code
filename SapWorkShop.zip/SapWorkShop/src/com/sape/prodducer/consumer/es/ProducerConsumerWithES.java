package com.sape.prodducer.consumer.es;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;


public class ProducerConsumerWithES {
	
	public static void main(String args[]){
		
        BlockingQueue<Integer> sharedQueue = new LinkedBlockingQueue<Integer>();

        ExecutorService pes = Executors.newFixedThreadPool(2);
        ExecutorService ces = Executors.newFixedThreadPool(2);

        pes.submit(new Producer(sharedQueue,1));
        pes.submit(new Producer(sharedQueue,2));
        ces.submit(new Consumer(sharedQueue,1));
        ces.submit(new Consumer(sharedQueue,2));

        pes.shutdown();
        ces.shutdown();
   }
	
	static class Producer implements Runnable {
	    private final BlockingQueue<Integer> sharedQueue;
	    private int threadNo;
	    public Producer(BlockingQueue<Integer> sharedQueue,int threadNo) {
	        this.threadNo = threadNo;
	        this.sharedQueue = sharedQueue;
	    }
	    @Override
	    public void run() {
	        for(int i=1; i<= 5; i++){
	            try {
	                int number = i+(10*threadNo);
	                System.out.println("Produced:" + number + ":by thread:"+ threadNo);
	                Thread.sleep(2000);
	                sharedQueue.put(number);
	            } catch (Exception err) {
	                err.printStackTrace();
	            }
	        }
	    }
	}
	
	static class Consumer implements Runnable {
	    private final BlockingQueue<Integer> sharedQueue;
	    private int threadNo;
	    public Consumer (BlockingQueue<Integer> sharedQueue,int threadNo) {
	        this.sharedQueue = sharedQueue;
	        this.threadNo = threadNo;
	    }
	    @Override
	    public void run() {
	        while(true){
	            try {
	                int num = sharedQueue.take();
	                Thread.sleep(2000);
	                System.out.println("Consumed: "+ num + ":by thread:"+threadNo);
	            } catch (Exception err) {
	               err.printStackTrace();
	            }
	        }
	    }   
	}
}

