package com.common;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class FailFastExample {
	
	public static void main(String[] args) {
	    
        List<String> list = new ArrayList<String>();
        
        list.add("one");
        list.add("two");
        list.add("three");
        
        Iterator<String> itr = list.iterator();
                
        /*while(itr.hasNext())
        {
            if(itr.next().equals("two"));
                list.add("four");    //will throw java.util.ConcurrentModificationException
        }*/
        
        
        ListIterator<String> ListItr =  list.listIterator();
        while(ListItr.hasNext()) {
        	String s = ListItr.next();
        	if(s.equals("two")) {
        		ListItr.add("four");
        	}
        }
        
        System.out.println("List content after operations:  "+list);

    }

}
