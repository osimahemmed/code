package com.java.design.pattern;

public class OperationMultiply implements Strategy {

	@Override
	public int doOperation(int a, int b) {
		return a*b;
	}

}
