package com.sape.design.flyweight;

public interface Shape {
	void draw();
}
