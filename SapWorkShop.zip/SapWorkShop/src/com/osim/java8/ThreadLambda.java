package com.osim.java8;

public class ThreadLambda {

	public static void main(String[] args) {
		
		Thread t = new Thread(() -> {
				System.out.println("thread is started");
		});

		t.start();
	}

}
