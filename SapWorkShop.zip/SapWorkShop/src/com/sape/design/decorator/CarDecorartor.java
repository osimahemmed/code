package com.sape.design.decorator;

public class CarDecorartor implements Car {
	
	private Car car;
	public CarDecorartor(Car car) {
		this.car = car;
	}
	
	public void assemble() {
		this.car.assemble();
	}

}
