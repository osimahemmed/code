package com.java.lamda;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class TestThread {

	public static void main(String[] args) {
		Thread t = new Thread(() -> System.out.println("Inside run"));
		t.run();
		
		Runnable r = (() -> System.out.println("inside runnable")); 
		r.run();
		
		TestThread th = new TestThread();
		List<String> list = new ArrayList<String>();
		list.add("osim");
		list.add("abhi");
		list.add("zakir");
		list.add("mohit");
		list.add("bilal");

		th.sort(list);
		System.out.println("sorting java7 "+list);
		th.sortJava8(list);
		System.out.println("sorting java8 "+list);
		
	}
	
	private void sort(List<String> list) {
		Collections.sort(list, new Comparator<String>() {
			public int compare(String s1, String s2) {
				return s1.compareTo(s2);
			}
		});
	}
	
	private void sortJava8(List<String> list) {
		Collections.sort(list, (s1, s2) -> s1.compareTo(s2));
	}

}
