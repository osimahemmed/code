package com.common;

public class MovesOnArray {

	public static void main(String[] args) {

		int  a[] = {1234, 3215};
		int  m[] = {2143, 4323};
		int count = moveCount(a, m);
		System.out.println(count);

	}

	private static int moveCount(int[] a, int[] m) {
		int numOfMoves = 0;
		int sizeOfFirstArr = a.length;
		int sizeOfMoveArr  = m.length;
		if(sizeOfFirstArr != sizeOfMoveArr) {
			return numOfMoves;
		}

		for(int i = 0; i< sizeOfFirstArr;i++) {
			String s1 = a[i]+"";
			String s2 = m[i]+"";

			char[] char1 = s1.toCharArray();
			char[] char2 = s2.toCharArray();

			for(int j = 0 ;j < char1.length; j++) {
				int valChar1 = (int) char1[j];
				int valChar2 = (int) char2[j];
				if(valChar1 > valChar2) {
					numOfMoves = numOfMoves +(valChar1-valChar2);
				} else {
					numOfMoves = numOfMoves + (valChar2-valChar1);
				}
			}
		}

		return numOfMoves;
	}
}