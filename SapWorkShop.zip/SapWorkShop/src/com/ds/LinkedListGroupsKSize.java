package com.ds;

import org.w3c.dom.ls.LSInput;

public class LinkedListGroupsKSize {
	
	
	Node head;
	
	static class Node {
		int data;
		Node next;
		public Node(int data) {
			this.data = data;
			next = null;
		}
	}
	
	
	
	Node curr = null;
	private void pushData(int new_data) {
		Node new_node = new Node(new_data);
		if(head == null) {
			head = new_node;
			curr = head;
		} else {
			curr.next = new_node;
			curr = curr.next;
		}
	}
	
	
	private void printList(Node head) {
		while(head != null) {
			System.out.printf("%d ",head.data);
			head = head.next;
		}
	}
	
	public static void main(String[] args) {
		
		LinkedListGroupsKSize llist = new LinkedListGroupsKSize();
		llist.pushData(1); 
        llist.pushData(2); 
        llist.pushData(3); 
        llist.pushData(4); 
        llist.pushData(5); 
        llist.pushData(6); 
        llist.pushData(7); 
        llist.pushData(8); 
        llist.pushData(9);
        llist.pushData(10);

        llist.printList(llist.head);
        
        llist.head = llist.reverse(llist.head, 4);
        
        System.out.println("Reversed list");
        llist.printList(llist.head);

	}


	private Node reverse(Node head, int k) {
		
		Node current = head;
		Node next = null;
		Node prev = null;
		int count = 0;
		/*int l = getLenght(head);
		if(l>=k)*/
		while(count < k && current != null) {
			next = current.next;
			current.next = prev;
			prev = current;
			current = next;
			count ++;
		}
		/* next is now a pointer to (k+1)th node  
        Recursively call for the list starting from current. 
        And make rest of the list as next of first node */
		
		if(next != null) {
			head.next = reverse(next, k);
		}
		
		return prev;
	}

}
