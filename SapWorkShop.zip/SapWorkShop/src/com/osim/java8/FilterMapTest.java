package com.osim.java8;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class FilterMapTest {

	public static void main(String[] args) {
		
		  Map<Integer, String> hMap = new HashMap<Integer, String>(); 
		  hMap.put(11, "Apple"); 
		  hMap.put(22, "Orange"); 
		  hMap.put(33, "Kiwi");  
		  hMap.put(44, "Banana");
	      
	      Map<Integer, String> result = hMap.entrySet()
	    		  						.stream()
	    		  						.filter(map -> map.getKey().intValue() <= 33)
	    		  						.collect(Collectors.toMap(map -> map.getKey(), map -> map.getValue()));
	      
	      System.out.println(result);

	}

}
