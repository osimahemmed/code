package com.sape.design.command;

public class CloseFileSystem implements Command {

	FileSystemReceiver fileSystem;
	public CloseFileSystem(FileSystemReceiver fs) {
		this.fileSystem = fs;
	}
	@Override
	public void execute() {
		this.fileSystem.closeFile();
		
	}

}
