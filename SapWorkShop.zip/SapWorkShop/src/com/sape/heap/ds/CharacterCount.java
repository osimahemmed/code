package com.sape.heap.ds;

import java.util.Arrays;

public class CharacterCount {

	public static void main(String[] args) {
		String str = "HelloWorld";
		//int[] counts = new int[256];
		int[] counts = new int[256];
		//int[] counts = new int[256];
		System.out.println(counts.length);

		for(int i = 0; i < str.length();i++) {
			char ch = str.charAt(i);
			counts[ch]++;
		}
		
		for(int i = 0; i < counts.length; i++) {
			if(counts[i] > 0) {
				System.out.println("Number of " + (char)i +": " +counts[i]);
			}
		}
		
		//System.out.println(Arrays.toString(counts));

	}

}
