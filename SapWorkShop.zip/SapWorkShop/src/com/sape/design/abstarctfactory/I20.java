package com.sape.design.abstarctfactory;

public class I20 implements ICar {

	@Override
	public void drive() {
		System.out.println("Driving i20...");
		
	}

}
