package com.abc.test;

public class MyExc1 extends Exception {

}
