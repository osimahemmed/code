package com.sape.immutable;

public class Child extends Parent {
	
	/*int m1(Integer a) {
		System.out.println("Child called");
		return 2;
	}*/
	int m1(String a) {
		System.out.println("child m1");
		return 3;
	}

}
