package com.sape.java8;

public interface ITest1 {
	default void defaultMethod1() {
		System.out.println("defaultmethod1 of Interface ITest1 ");
	}
	
	default void defaultMethod2() {
		System.out.println("defaultMethod2 method of Interface ITest1 ");
	}
}
