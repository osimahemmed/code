package com.bc.junit;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;

public class SimpleTest {
	
	private Collection<Object> collection;
	
	@Before
	public void setup() {
		collection = new ArrayList<Object>();
	}
	
	@Test
	public void testEmptyCollection() {
		assertTrue(collection.isEmpty());
	}
	
	@Test
	public void testOneItemCollection() {
		collection.add("item1");
		assertEquals(1, collection.size());
	}
	
	/*Given this test the methods might execute in the following order:
		setUp()
		testEmptyCollection()
		setUp()
		testOneItemCollection()
		
		
		The ordering of test-method invocations is not guaranteed, so testOneItemCollection() might be executed before 
		testEmptyCollection(). But it doesn't matter, because each method gets its own instance of the collection.
	 */

}
