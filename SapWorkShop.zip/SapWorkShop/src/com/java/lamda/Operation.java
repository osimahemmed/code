package com.java.lamda;

public class Operation {

	public static void main(String[] args) {
		 MathOperation add = (a,b) -> a+b;
		 Operation op = new Operation();

	}

}
