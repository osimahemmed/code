package com.common;

import java.util.concurrent.RecursiveTask;

//Task for computing the sum of array elements.
class SumCalculatorTask extends RecursiveTask<Integer> {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7018962918950774616L;
	int[] numbers;

	SumCalculatorTask(int[] numbers) {
		this.numbers = numbers;
	}

	@Override
	protected Integer compute() {
		int sum = 0;
		for (int i : numbers) {
			sum += i;
		}
		return sum;
	}
}