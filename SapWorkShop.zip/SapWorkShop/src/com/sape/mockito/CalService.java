package com.sape.mockito;

public class CalService {
	ICalculator cal;
	
	public int addTwoNumbers(int x, int y) {
		return cal.add(x, y);
	}
	
	/*public static void main(String[] args) {
		CalService ser = new CalService();
		System.out.println(ser.addTwoNumbers(3, 3));
	}*/

	public ICalculator getCal() {
		return cal;
	}

	public void setCal(ICalculator cal) {
		this.cal = cal;
	}
}
