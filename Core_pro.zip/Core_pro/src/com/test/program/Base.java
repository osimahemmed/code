package com.test.program;

class Base {
	
	 protected int b = 45;
	
	Base(){
		b = 10;
		System.out.println("inside constructor A" +b);
	}
	
}