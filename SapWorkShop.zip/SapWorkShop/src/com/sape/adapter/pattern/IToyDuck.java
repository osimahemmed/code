package com.sape.adapter.pattern;

public interface IToyDuck {
	
	public void squeak();
	
}
