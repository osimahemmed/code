package com.ds;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

public class DictionaryWordDemo {
	
    public static void main(String ...s) {
    	
           Set<String> dictionary = new HashSet<>(Arrays.asList("i","like","sam","sung","samsung","mobile","ice","cream","icecream","man","go","mango"));
           Set<String> output = new HashSet<>();
           
           DictionaryWordDemo obj = new DictionaryWordDemo();
           Map<Integer,Set<String>> wordsMap = obj.subWords("ilikesamsung");
           for(Map.Entry<Integer, Set<String>> entry : wordsMap.entrySet()){
                  Set<String> stringSet = entry.getValue();
                  for(String data : stringSet){
                        if(dictionary.contains(data)){
                               if(!output.contains(data)){
                                      output.add(data);
                               }
                        }
                  }
           }
           System.out.println(output);
           
    }
    
    private Map<Integer,Set<String>> subWords(String inputStr) {
    	
           Map<Integer,Set<String>> wordsMap = new HashMap<>();
           for(int wordLength=1;wordLength<=inputStr.length();wordLength++){
                  int start=0;
                  int end = start+wordLength;
                  while(end<=inputStr.length()){
                        String str = inputStr.substring(start, end);
                        Set<String> strSet = wordsMap.get(wordLength);
                        if(strSet == null){
                               strSet = new LinkedHashSet<>();
                               wordsMap.put(wordLength, strSet);
                        }
                        strSet.add(str);
                        start++;
                        end++;
                  }
           }
           //System.out.println(wordsMap);
           /*for(Map.Entry<Integer, Set<String>> entry : wordsMap.entrySet()){
                  Integer length = entry.getKey();
                  Set<String> value = entry.getValue();
                  System.out.println("length="+length+" set="+value);
           }*/
           return wordsMap;
    }

}

