package com.ds;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class FormLargestNumber {

	public static void main(String[] args) {
		
		int num = 51982 ;
		int largest = formLargest(num);
		System.out.println(largest);
	}
	
	private static int formLargest(int num) {
		List<String> listNum = new ArrayList<String>();
		while(num > 0) {
			int remainder = num % 10;
			listNum.add(String.valueOf(remainder));
			num  = num / 10;
		}
		
		int res = getLargest(listNum);
		return res;
	}
	
	private static int getLargest(List<String> list) {
		String str1 = "";
		Collections.sort(list, new Comparator<String>() {
			@Override
			public int compare(String o1, String o2) {
				String orig = o1+o2;
				String reve = o2+o1;
				return reve.compareTo(orig);
			}
		});
		
		for(String str : list) {
			str1 = str1+str;
		}
		return Integer.valueOf(str1);
	}

}
