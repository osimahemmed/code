public class Hello{ 
 public void doit() { 
   System.out.println("Hello world") ;
 }
}