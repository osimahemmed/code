package com.sape.generics;

public class B extends A {

	public B() {
		System.out.println("B's constructor");
	}
}
