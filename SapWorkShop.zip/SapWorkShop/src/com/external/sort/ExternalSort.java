package com.external.sort;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

public class ExternalSort {

	public static Comparator<String> defaultcomparator = new Comparator<String>() {
		@Override
		public int compare(String r1, String r2) {
			return r1.compareTo(r2);
		}
	};

	public static long memoryAvailable() {
		System.gc();

		Runtime runtime = Runtime.getRuntime();

		long totalMemory = runtime.totalMemory();
		System.out.println("total : " + totalMemory/(1024 * 1024));

		long freeMemory = runtime.freeMemory();
		System.out.println("freeMemory : " + freeMemory/(1024 * 1024));

		return freeMemory;
	}

	public static long sizeOfBlocks(final long sizeoffile,
			final int maxtmpfiles, final long freeMemory) {

		long blocksize = sizeoffile / maxtmpfiles
				+ (sizeoffile % maxtmpfiles == 0 ? 0 : 1);

		if (blocksize < freeMemory / 2) {
			blocksize = freeMemory / 2;
		}
		return blocksize;
	}

	public static List<File> filesChunks(File file, Comparator<String> cmp,int maxtmpfiles, File tmpdirectory) {

		BufferedReader bufferedReader = null;
		List<File> files = null;
		long blocksize ;
		List<String> tmplist ;
		String line = "";

		try {
			bufferedReader =  new BufferedReader(new FileReader(file));
			files = new ArrayList<>();
			blocksize = sizeOfBlocks(file.length(),maxtmpfiles, memoryAvailable());
			System.out.println("block size : " + blocksize);
			tmplist = new ArrayList<>();

			while (line != null) {
				long currentblocksize = 0;
				while ((currentblocksize < blocksize) && ((line = bufferedReader.readLine()) != null)) {
					tmplist.add(line);
				}

				files.add(sortAndSave(tmplist, cmp, tmpdirectory));
				tmplist.clear();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return files;
	}

	public static File sortAndSave(List<String> tmplist,Comparator<String> cmp, File tmpdirectory) throws IOException {

		Collections.sort(tmplist, cmp);

		File newtmpfile = File.createTempFile("sortInBatch","flatfile", tmpdirectory);
		//		newtmpfile.deleteOnExit();
		try (BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(newtmpfile)))) {
			for (String r : tmplist) {
				bufferedWriter.write(r);
				bufferedWriter.newLine();
			}
		}
		return newtmpfile;
	}

	public static void mergeFiles(List<File> files, File outputfile,final Comparator<String> cmp) throws IOException {

		ArrayList<BinaryFileBuffer> listOfFiles = new ArrayList<>();
		BufferedReader bufferedReader;
		BufferedWriter bufferedWriter = null;
		BinaryFileBuffer binaryFileBuffer;

		for (File f : files) {
			bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(f)));
			binaryFileBuffer = new BinaryFileBuffer(bufferedReader);
			listOfFiles.add(binaryFileBuffer);
		}

		try {

			bufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outputfile)));

			PriorityQueue<BinaryFileBuffer> priorityQueue = new PriorityQueue<>(11, new Comparator<BinaryFileBuffer>() {
				@Override
				public int compare(BinaryFileBuffer i,BinaryFileBuffer j) {
					return cmp.compare(i.peek(), j.peek());
				}
			});

			for (BinaryFileBuffer buffReader: listOfFiles) {
				if (buffReader != null) {
					priorityQueue.add(buffReader);
					System.out.println("priority queue : " + priorityQueue.toString());
				}
			}

			while (priorityQueue.size() > 0) {
				BinaryFileBuffer bfb = priorityQueue.poll();
				String r = bfb.pop();
				bufferedWriter.write(r);
				bufferedWriter.newLine();
				if (bfb.empty()) {
					bfb.fbr.close();
				} else {
					priorityQueue.add(bfb); // add it back
				}
			}

		}finally {
			bufferedWriter.close();
			System.out.println("finally");
		}
	}

	public static void main(String[] args) throws IOException {

		File inputFile = null;
		File tempFile = null;
		File outputFile = null;
		int maxtmpfiles = 1024;

		if(args[0] == null) {
			System.out.println("enter the input file");
		}
		else if(args[1] == null) {
			System.out.println("enter the output file");
		}else {
			inputFile = new File(args[0]);
			outputFile = new File(args[1]);
		}

		Comparator<String> comparator = defaultcomparator;

		List<File> listOfFiles = filesChunks(inputFile, comparator, maxtmpfiles, tempFile);
		mergeFiles(listOfFiles,outputFile, comparator);
	}
}
