package com.sape.design.abstarctfactory;

public class I10 implements ICar {

	@Override
	public void drive() {
		System.out.println("Driving i10");
		
	}

}
