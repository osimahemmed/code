package com.sape.decorator.design;

public class Onion extends PizzaTopping {

	public Onion(Pizza pizza) {
		this.pizza = pizza;
	}

	@Override
	public String descriotion() {
		return "Onion";
	}

	@Override
	public Double cost() {
		return pizza.cost() + 2.0;
	}

}
