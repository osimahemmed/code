package com.java.design.command;

public interface Command {

	public void execute();

}
