package com.common;

public class StaticOverriden {

	public static void main(String[] args) {
		A a = new B();
		a.sayHello();
	}

}
