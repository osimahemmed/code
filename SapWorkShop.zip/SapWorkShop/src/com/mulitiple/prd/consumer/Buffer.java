package com.mulitiple.prd.consumer;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Buffer {

	private BlockingQueue<Integer> queue;
	int n;

	public Buffer(int size) {
		queue = new ArrayBlockingQueue<Integer>(size);
	}

	public void put(int data) {
		try {
			System.out.println("put : " + data);
			queue.put(data);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	public int get() {
		try {
			n = queue.take();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return n;
	}
}
