package com.java.lamda;

public interface IGreetingService {
	void sayMessage(String message);
}
