package com.sape.lock.custom;

public class ReentrantLockCustomTest {
	
	public static void main(String[] args) {

		 

  		ICustomLock LockCustom=new ReentrantCustomLock();

  		MyRunnable myRunnable = new MyRunnable(LockCustom);

  		new Thread(myRunnable,"Thread-1").start();

  		new Thread(myRunnable,"Thread-2").start();

  		

	}

}
