package com.common;

public class Parent {
	
	public void show(Object obj)
    {
        System.out.println("Inside parenet method");
    }
	
	public Integer print() {
		System.out.println("returning from Parent");
		return 3;
	}


}
