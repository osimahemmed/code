package com.sape.design.command;

public interface Command {
	void execute();
}
