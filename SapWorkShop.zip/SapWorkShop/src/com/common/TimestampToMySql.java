package com.common;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class TimestampToMySql {

	public static void main(String[] args) throws ParseException {
		
		/*java.util.Date utilDate = new java.util.Date();
	    java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
	    System.out.println("utilDate:" + utilDate);
	    System.out.println("sqlDate:" + sqlDate);
		
		Date now = new Date();
        String pattern = "yyyy-MM-dd";
        SimpleDateFormat formatter = new SimpleDateFormat(pattern);
        String mysqlDateString = formatter.format(now);
        
        java.sql.Date sqlDate =  java.sql.Date.valueOf(mysqlDateString);
        
        System.out.println("osim: " + sqlDate);
        System.out.println("Mysql's Default Date Format: " + mysqlDateString);
        
        Date myDateObj =  formatter.parse(mysqlDateString);
        System.out.println("Date in java.util.Date Obj : " + myDateObj);
		java.util.Date date = new java.util.Date();
		
		java.sql.Date sqlDate1 = new java.sql.Date(date.getTime());
        java.sql.Timestamp sqlTime = new java.sql.Timestamp(date.getTime());
        
        System.out.println("Hi   " + sqlDate1);
        System.out.println(" sqlTime " +sqlTime);
		//Date date = new Date(); 
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
		
		//Date date5 = new Date();
		 System.out.println(dateFormat.format(date));
		 
		String date2 = dateFormat.format(date);
		System.out.println("date2 " + date2);
		java.sql.Date  sqlDate = new java.sql.Date(dateFormat.format(date));
		System.out.println("sqlDate " + sqlDate);
		
		Calendar calendar = Calendar.getInstance();
		
		java.sql.Timestamp timeStamp = new java.sql.Timestamp(calendar.getTime().getTime());
		
		System.out.println(timeStamp);*/
		
		Calendar calendar = Calendar.getInstance();
	    java.sql.Timestamp ourJavaTimestampObject = new java.sql.Timestamp(calendar.getTime().getTime());
	    System.out.println(ourJavaTimestampObject);
	    
	    // (3) create a 


	}

}
