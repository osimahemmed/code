package com.sape.prd.consumer;

import java.util.concurrent.BlockingQueue;

public class Consumer implements Runnable {
	private final BlockingQueue<Integer> sharedQueue;
	String threadName;
	public Consumer(BlockingQueue<Integer> queue) {
		this.sharedQueue = queue;
	}
	@Override
	public void run() {
		threadName = Thread.currentThread().getName();
		while(true) {
			try {
				int num = sharedQueue.take();
				System.out.println("Consumed " +num+ " by " +threadName);
				Thread.sleep(2000);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}
	
}
