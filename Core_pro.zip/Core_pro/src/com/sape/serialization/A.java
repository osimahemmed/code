package com.sape.serialization;


public class A {

	int i;
	public A(int i) {
		this.i= i;
	}
	public A() {
		i = 50;
		System.out.println("A's contructor called");
	}
}
