package com.java.concurrency.condition.api;

public class Consumer extends Thread {
	
	ProducerConsumerImpl pc;
	
	public Consumer(ProducerConsumerImpl pc) {
		super("Consumer");
		this.pc = pc;
	}
	
	@Override
	public void run() {
		try {
			pc.get();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
