package com.bc.junit;

public class NullTest {
	
	public String testNull() {
		String str = "abc";
		if (str.equals("abc")) {
			return null;
		} else {
			return null;
		}
			
	}

}
