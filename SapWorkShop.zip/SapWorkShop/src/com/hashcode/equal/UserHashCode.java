package com.hashcode.equal;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class UserHashCode {
	private String name;
	private int age;
	private String passport;
	
	
	public UserHashCode(String na, int ag, String pass) {
		this.name = na;
		this.age = ag;
		this.passport = pass;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getPassport() {
		return passport;
	}
	public void setPassport(String passport) {
		this.passport = passport;
	}
	
	@Override
	public boolean equals(Object o) {
		if(o == null)
			return false;
		if(o == this)
			return true;
		if(!(o instanceof UserHashCode)) {
			return false;
		}
		
		UserHashCode user = (UserHashCode) o;
		
		return this.getName().equals(user.getName()) &&
				this.age == user.getAge() &&
				this.passport.equals(user.getPassport());
		
		/*return user.name.equals(name) &&
				user.age == age &&
				user.passport.equals(passport);*/
	}
	
	@Override
	public int hashCode() {
		int result = 17;
		result = 31 * result + name.hashCode();
		result = 31 * result + age;
		result = 31 * result + passport.hashCode();
		return result;
	}

	public static void main(String[] args) {
		UserHashCode user1 = new UserHashCode("osim", 34, "E9252912");
		UserHashCode user2 = new UserHashCode("osim", 34, "E9252912");
		System.out.println(user1.equals(user2));
		//User user3 = new User();
		//User user4 = new User();
		//user3.setName("osim");
		//user4.setName("osim");
		//System.out.println(user3.equals(user4));
		Map<UserHashCode, Integer> map = new HashMap<UserHashCode, Integer>();
		map.put(user1, 1);
		map.put(user2, 2);
		System.out.println(" Printing map " +map);
		System.out.println("Getting map value " + map.get(user2));
		Set<UserHashCode> set = new HashSet<UserHashCode>();
		set.add(user1);
		set.add(user2);
		System.out.println("Printing set "+set);
	}
}
 