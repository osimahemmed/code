package com.java.design.pattern;

public interface Shape {
	void draw();

}
