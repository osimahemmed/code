package com.sape.generic;

public class GenericClass<T> {
	T t;
	
	public GenericClass(T t) {
		this.t = t;
	}
	
	public void setT(T t) {
		this.t = t;
	}
	
	public T getT() {
		return t;
	}
	
	
	public static void main(String[] args) {
		GenericClass<Integer> gen1 = new GenericClass<Integer>(new Integer(123));
		gen1.setT(120);
		System.out.println(gen1.getT());
		
		GenericClass<String> gen2 = new GenericClass<String>("String");
	}
}
