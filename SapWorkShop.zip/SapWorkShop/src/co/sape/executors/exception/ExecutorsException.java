package co.sape.executors.exception;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExecutorsException {

	public static void main(String[] args) {
		
			  ExecutorService pool = Executors.newFixedThreadPool(10);
			 
			  doSomething(pool);
			  
	}
	
	public static void doSomething(ExecutorService pool) {
		pool.execute(new Task());
	}
}