package com.ds;

public class StackUsingArray {
	
	int size;
	int top;
	int[] arr;
	
	public StackUsingArray(int size) {
		this.size = size;
		this.arr = new int[size];
		this.top = -1;
	}
	
	public boolean isFull() {
		return (size-1 == top);
	}
	
	public boolean isEmpty() {
		return (top == -1);
	}
	
	public int peek() {
		return arr[top];
	}
	
	public void push(int data) {
		if(!isFull()) {
			top ++;
			arr[top] = data;
		} else {
			System.out.println("Stack is full");
		}
	}
	public int pop() {
		if(!isEmpty()) {
			int returnPop = top;
			top--;
			System.out.println("popped element is " + arr[returnPop]);
			return arr[returnPop];
			
		} else {
			System.out.println("stack is empty");
			return -1;
		}
	}
	
	public static void main(String[] args) {
		
		StackUsingArray stack = new StackUsingArray(4);
		stack.pop();
		stack.push(10);
		stack.push(20);
		stack.push(30);
		stack.push(40);
		//stack.push(40);
		//stack.pop();
		//stack.pop();
		/*StackUsingArray stack = new StackUsingArray(10);
		stack.pop();
		stack.push(10);
		stack.push(30);
		stack.push(50);
		stack.push(40);
		stack.push(20);
		System.out.println("********************");
		stack.pop();
		stack.pop();
*/	}
}
