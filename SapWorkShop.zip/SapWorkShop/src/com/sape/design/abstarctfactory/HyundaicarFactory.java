package com.sape.design.abstarctfactory;

public class HyundaicarFactory implements ICarFactory {

	@Override
	public ICar createCar(String carType) {
		if("i10".equalsIgnoreCase(carType)) {
			return new I10();
		}
		if("i20".equalsIgnoreCase(carType)) {
			return new I20();
		}
		return null;
	}

}
