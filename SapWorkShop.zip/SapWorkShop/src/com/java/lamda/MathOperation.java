package com.java.lamda;

public interface MathOperation {
	int add(int a, int b);

}
