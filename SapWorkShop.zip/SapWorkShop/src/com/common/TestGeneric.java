package com.common;

import java.util.Arrays;
import java.util.List;

public class TestGeneric {

	public static void main(String[] args) {

		List<Integer> ints = Arrays.asList(1, 2, 3); 
		List<? extends Number> nums = ints;  
		//List<Number extends ?> nums = ints; 
		
		System.out.println(nums);


	}

}
