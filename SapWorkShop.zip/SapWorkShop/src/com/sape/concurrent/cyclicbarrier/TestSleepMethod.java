package com.sape.concurrent.cyclicbarrier;

public class TestSleepMethod implements Runnable {

	public static void main(String[] args) throws InterruptedException {
		
		Thread t1 = new Thread(new TestSleepMethod(), "Thread1");
		Thread t2 = new Thread(new TestSleepMethod(), "Thread2");
		t1.start();
		t1.join(1);
		t2.start();
		

	}
	
	public static void start() {
		System.out.println("starting");
	}

	@Override
	public void run() {
		String currentThread = Thread.currentThread().getName();
		for(int i=1;i<4;i++) {
			try {
				
				Thread.sleep(2000);
			} catch (InterruptedException ie) {
				ie.printStackTrace();
			}
			//System.out.println(i);
			System.out.println(currentThread +"  printing "+ i);
		}
		
	}

}
