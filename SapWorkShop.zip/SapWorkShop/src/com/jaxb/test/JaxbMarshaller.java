package com.jaxb.test;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

public class JaxbMarshaller {

	public static void main(String[] args) {
		Customer customer = new Customer();
		
		customer.setId(100);
		customer.setName("osim");
		customer.setAge(29);
		
		try {
			File file = new File("D:\\customer100.xml");
			JAXBContext context = JAXBContext.newInstance(Customer.class);
			Marshaller masrhaller = context.createMarshaller();
			masrhaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			masrhaller.marshal(customer, file);
			masrhaller.marshal(customer, System.out);
		} catch (JAXBException e) {
			System.out.println("Exception " + e.getMessage());
			e.printStackTrace();
		}

	}

}
