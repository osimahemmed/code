package com.sape.immutable;

public class ParentChildTest {

	public static void main(String[] args) {
		 
		Parent p = new Child();
		p.m1(null);

	}

}
