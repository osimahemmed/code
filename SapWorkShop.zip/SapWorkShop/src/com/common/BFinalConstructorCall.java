package com.common;

public class BFinalConstructorCall extends AFinalConstructor {

	public static void main(String[] args) {
		
		AFinalConstructor a = new BFinalConstructorCall();
	}

}
