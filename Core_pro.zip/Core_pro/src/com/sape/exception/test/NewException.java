package com.sape.exception.test;

public class NewException extends Throwable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NewException(String s) {
		super(s);
	}

}
