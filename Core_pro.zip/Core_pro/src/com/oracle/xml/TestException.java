package com.oracle.xml;

class A1{
	public void print() throws RuntimeException
	{
		System.out.println("iam in A1");
	}
}
class B2
{
	public void print() throws RuntimeException
	{
		System.out.println("Iam in B2");
	}
}
public class TestException {


	public static void main(String[] args) {
	

	}

}
