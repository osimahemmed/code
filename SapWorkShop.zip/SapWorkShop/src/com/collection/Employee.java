package com.collection;

public class Employee {
	
	
	
	private int id;
	private String name;
	
	public Employee(int id, String name) {
		this.id = id;
		this.name = name;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public int hashCode() {
		int result = 17;
		result = result*31 + id;
		result = result*31 + name.hashCode();
		return result;
	}
	
	public boolean equals(Object o) {
			
		if(o == null)
			return false;
		if(o == this)
			return true;
		if(!(o instanceof Employee)) {
			return false;
		}
		
		Employee emp = (Employee) o;
		
		return this.id == emp.getId() &&
			   this.name.equals(emp.getName());
		
	}
	
	@Override
	public String toString() {
		return "id: "+ id+ " name " + name;
	}

}
