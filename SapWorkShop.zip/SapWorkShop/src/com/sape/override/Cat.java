package com.sape.override;

public class Cat extends Animal {
	 
    public void eat() {
         System.out.println("eat from Cat");
    }
 
    public void meow() {
         System.out.println("meow from Cat");
    }
}
