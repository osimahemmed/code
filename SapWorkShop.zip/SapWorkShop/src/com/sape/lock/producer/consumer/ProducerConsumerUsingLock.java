package com.sape.lock.producer.consumer;

public class ProducerConsumerUsingLock {

	public static void main(String[] args) {
		ProducerConsumerImpl sharedObject  = new ProducerConsumerImpl();
		
		Producer p = new Producer(sharedObject);
		Consumer c = new Consumer(sharedObject);
		
		p.start();
		c.start();

	}

}
