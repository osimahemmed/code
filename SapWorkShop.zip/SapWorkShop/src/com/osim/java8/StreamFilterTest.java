package com.osim.java8;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamFilterTest {

	public static void main(String[] args) {
		
		List<String> names = Arrays.asList("Melisandre","Sansa","Jon","Daenerys","Joffery");
		
				//names.stream().filter(s->s.length() > 6).forEach(d -> System.out.println(d));
				
				
		/*List<String> longNames = names.stream()
										.filter(s -> s.length() > 6)
										.collect(Collectors.toList());*/
		List<String> longNames = names.stream()
									.filter(s -> s.length() > 4)
									.collect(Collectors.toList());
		
		longNames.forEach(System.out::println);
		
		List<String> longName = names.stream()
										.filter(s -> s.length() > 6 && s.length() < 8)
										.collect(Collectors.toList());
		
		longName.forEach(System.out::println);
		System.out.println("osim " +longName);
		
		List<Integer> num = Arrays.asList(1,2,3,4,5,6);
		
		List<Integer> squares = num.stream()
									.map(s -> s*s)
									.collect(Collectors.toList());
		
		System.out.println(squares);
		squares.forEach(System.out::println);
		
		

	}

}
