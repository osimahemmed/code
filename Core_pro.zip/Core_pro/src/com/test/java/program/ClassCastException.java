package com.test.java.program;

import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class ClassCastException {

	public static void main(String[] args) {
		
		Set set = new TreeSet();
		set.add("osim");
		set.add(1);

		System.out.println(set);
	}

}
