package com.common;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;

public class ReArrangeList {


	 // Function to rearrange a given list such that it
   // consists of alternating minimum maximum elements
   // using LinkedList
	//Queue<String> qu = new PriorityQueue<String>();
   public static void alternateSort(LinkedList<Integer> ll) 
   {
       Collections.sort(ll);
        
       for (int i = 1; i < (ll.size() + 1)/2; i++)
       {
           Integer x = ll.getLast();
           ll.removeLast();
           ll.add(2*i - 1, x);
       }
        
       System.out.println(ll);
   }
    
   public static void main (String[] args) throws java.lang.Exception
   {
       // input list
       Integer arr[] = {1, 3, 8, 2, 7, 5, 6, 4, 12};
        
       // convert array to LinkedList
       LinkedList<Integer> ll = new LinkedList<Integer>(Arrays.asList(arr));
        
       // rearrange the given list
       alternateSort(ll);
   }


}
