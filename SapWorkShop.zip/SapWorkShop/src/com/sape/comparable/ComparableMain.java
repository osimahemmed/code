package com.sape.comparable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ComparableMain {

	public static void main(String[] args) {
		Country india = new Country(5, "India");
		Country china = new Country(4, "China");
		Country brazil = new Country(3, "Brazil");
		Country uae = new Country(2, "UAE");
		Country russia = new Country(1, "Russia");
		
		List<Country> listCountry = new ArrayList<Country>();
		listCountry.add(india);
		listCountry.add(china);
		listCountry.add(brazil);
		listCountry.add(uae);
		listCountry.add(russia);
		
		System.out.println("Before sort");
		for(Country country : listCountry) {
			System.out.println("countryId "+country.getCountryId()+"||"+"Country Name " +country.getCountryName());
		}
		
		Collections.sort(listCountry);
		System.out.println("After sort");
		for(Country country : listCountry) {
			System.out.println("countryId "+country.getCountryId()+"||"+"Country Name " +country.getCountryName());
		}

	}

}
