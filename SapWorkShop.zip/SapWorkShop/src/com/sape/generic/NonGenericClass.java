package com.sape.generic;

public class NonGenericClass {
	
	public <T> NonGenericClass(T t1) {
		T t2 = t1;
		System.out.println(t2);
	}
	
	static <T> void genericMethod(T t1) {
		T t2 = t1;
		System.out.println(t2);
		
	}
	
	public static void main(String[] args) {
		
		NonGenericClass nonGen1 = new NonGenericClass(123);
		NonGenericClass nonGen2 = new NonGenericClass("sting");
		/*NonGenericClass.genericMethod(new Integer(123));
		NonGenericClass.genericMethod("I am a string");
		NonGenericClass.genericMethod(new Double(25.89));*/
	}

}
