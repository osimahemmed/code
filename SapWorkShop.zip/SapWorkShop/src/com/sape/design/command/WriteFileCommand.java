package com.sape.design.command;

public class WriteFileCommand implements Command{

	FileSystemReceiver fileSystem;
	public WriteFileCommand(FileSystemReceiver fs) {
		this.fileSystem = fs;
	}
	@Override
	public void execute() {
		this.fileSystem.writeFile();
		
	}

}
