package com.ds;

import java.util.Arrays;

public class StringHasUniqueCharOrNot {

	public static void main(String[] args) {
		boolean b = isUniqueChars("java");
		System.out.println(b);
	}
	
	private static boolean isUniqueChars(String name) {
		
		char [] chArray = name.toCharArray();
		Arrays.sort(chArray);
		for(int i = 0; i < chArray.length;i++) {
			if(chArray[i] != chArray[i+1]) {
				continue;
			} else {
				return false;
			}
		}
		return true;
	}

}
