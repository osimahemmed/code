package com.sape.design.abstarctfactory;

public class HondaCarfactory implements ICarFactory{

	@Override
	public ICar createCar(String carType) {
		if("brio".equalsIgnoreCase(carType)) {
			return new Brio();
		}
		if("city".equalsIgnoreCase(carType)) {
			return new City();
		}
		
		return null;
	}

}
