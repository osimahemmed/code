package com.osim.java8;

import java.util.function.IntBinaryOperator;

public class TestInterface {

	public static void main(String[] args) {
		
		MyFunctionalInterface sum = (a,b) -> a+b;
		
		System.out.println("sum is : "+ sum.add(5, 5));
		
		IntBinaryOperator sum1 = (a,b) -> a+b;
		System.out.println(sum1.applyAsInt(10, 20));
	}

}
