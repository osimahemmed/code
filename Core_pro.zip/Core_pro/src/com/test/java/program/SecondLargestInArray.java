/*
 * Step 1:

    Iterate the given array

Step 2 (first if condition arr[i] > largest):

    If current array value is greater than largest value then

        Move the largest value to secondLargest and make

        current value as largest

Step 3 (second if condition arr[i] > secondLargest )  

  If the current value is smaller than largest and greater than secondLargest  then

        the current value becomes secondLargest
 */

package com.test.java.program;

public class SecondLargestInArray {

	public static void main(String[] args) {
		 
		//int arr[] = { 14, 46, 47, 86, 92, 52, 48, 36, 66, 85 };
		int arr[] = {5,4,3,2,1};
		int largest = arr[0];
		int secondLargest = arr[0];
		
		System.out.println("The given array is:" );
		
 
		System.out.println("\nSecond largest number is:" + secondLargest);
 
	}

}
