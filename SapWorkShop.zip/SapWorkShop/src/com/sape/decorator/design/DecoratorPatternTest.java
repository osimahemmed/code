package com.sape.decorator.design;

public class DecoratorPatternTest {

	public static void main(String[] args) {
		Pizza panPizza = new PanPizaa();
		panPizza = new Tomatoes(panPizza);
		panPizza = new Cheese(panPizza);
		panPizza = new Onion(panPizza);
		
		System.out.println("You ordered - pan pizza");
		System.out.println("your total cost is " + panPizza.cost());
		System.out.println("description " + panPizza.descriotion());
	}

}
