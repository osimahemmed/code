package com.test.java.program;

import java.util.Random;

public class RandonTestNumber {

	public static void main(String[] args) {
		double ds = updateCommodity(1700);
		System.out.println(ds);
	}

	private static double updateCommodity(double price) {

		Random random = new Random();

		int value = 0;
		int choice = random.nextInt(3);
		if (price < 1500) {
			price = 2000;
		} else {
			if (price == 0)
				choice = 2;
			if (choice == 0) {
				System.out.println(choice);

				value = random.nextInt((int) price);
				value = value + 1;
				System.out.println("value is" + value);
				price -= value;

			}
			if (choice == 1) {
				System.out.println(choice);
				value = random.nextInt((int) price / 2 + 1);
				value = value + 1;

				System.out.println("value to be added is is" + value);

				price += value;

			}
			if (choice == 2) {
				System.out.println(choice);
				value = 0;

				System.out.println(" value to be subtracted is is" + value);

			}

		}

		return price;

	}
}
