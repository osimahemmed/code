//Invoker is a simple class that encapsulates the Command and passes the request to the command 
//object to process it
package com.java.design.command;

public class SimpleRemoteControl {
	private Command command;
	
	public SimpleRemoteControl() {}
	
	public void setCommand(Command command) {
		this.command = command;
	}
	
	public void buttonWasPressed() {
		command.execute();
	}

}
