package com.sape.ds.practice;

import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;

public class StackUsingQueues {
	
	Queue<Integer> q1 = new LinkedList<Integer>();
	Queue<Integer> q2 = new LinkedList<Integer>();
	
	public int peek() {
		if(q1.peek() == null) {
			System.out.println("Stack is empty");
			int i = 0;
			return i;
		} else {
			int pop = q1.remove();
			return pop;
		}
	}
	
	public void push(int data) {
		if(q1.peek() == null) {
			q1.add(data);
		} else {
			for(int i = q1.size(); i > 0; i--) {
				q2.add(q1.remove());
			}
			q1.add(data);
			for(int j = q2.size(); j > 0;j--) {
				q1.add(q2.remove());
			}
		}
	}

	public static void main(String[] args) {
		StackUsingQueues q1 = new StackUsingQueues();
		q1.push(1);
		q1.push(2);
		q1.push(3);
		q1.push(4);
		
		System.out.println(q1.peek());

	}

}
