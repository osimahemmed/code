package com.ds;

import java.util.HashSet;
import java.util.Set;

public class WordsContainInDictionary1 {

	public static void main(String[] args) {

		//String input = "IlikeFacebook";
		String input = "IlikeFacebooktest";

		Set<String> dict = new HashSet<String>();

		dict.add("like");
		dict.add("face");
		dict.add("book");
		dict.add("facebook");
		dict.add("i");

		boolean b = validWords(input, dict);
		System.out.println("flag " + b);

		/* Set<String> dictionary = new HashSet<>();
		 
		 dictionary.add("I"); 
		 dictionary.add("like");
		 dictionary.add("had");
		 dictionary.add("play"); 
		 dictionary.add("to");
		 
		 // System.out.println(dictionary);
		  
		 String str = "Ihadliketoplay"; 
		 boolean b = findValidString(str,dictionary); 
		 System.out.println("flag " + b);*/
		 
	}

	private static boolean validWords(String input, Set<String> dict) {

		int left = 0;
		int right = input.length();
		boolean flag = false;

		// boolean[] status = new boolean[input.length()];

		while (left < right) {
			for (int i = 0; i <= right; i++) {
				String word = input.substring(i, right);
				word = word.toLowerCase();
				if (dict.contains(word)) {
					right = i;
					System.out.println(word);
					flag = true;
				}
				//right = i;
			}

		}
		return flag;
	}

}
