package com.sape.checked.exception;

public class NameNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5290090453568877121L;
	
	public NameNotFoundException() {
		super();
	}
	
	public NameNotFoundException(String message) {
		super(message);
	}

}
