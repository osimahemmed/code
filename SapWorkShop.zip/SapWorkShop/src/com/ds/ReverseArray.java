package com.ds;

public class ReverseArray {
	
    static int count = 0;
    
	public static void main(String[] args) {
		int[] arr = {4,23,1,6,8,90};
		//reverseArr(arr);
		reverseRecurssively(arr, 0, arr.length-1);
		for(int i : arr) {
			System.out.println(i);
		}

	}
	
	private static void reverseArr(int[] arr) {
		int start = 0;
		int end = arr.length-1;
		int temp;
		while(start < end) {
			temp = arr[start];
			arr[start] = arr[end];
			arr[end] = temp;
			start++;
			end--;
		}
		
	}
	
	private static void reverseRecurssively(int[] arr, int start, int end) {
		System.out.println(count++);
		System.out.println();
		int temp;
		if(start >= end)
			return;
		temp = arr[start];
		arr[start] = arr[end];
		arr[end] = temp;
		reverseRecurssively(arr, start+1, end-1);
		
	}

}
