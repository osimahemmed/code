package com.sape.design.abstarctfactory;

public interface ICar {
	void drive();
}
