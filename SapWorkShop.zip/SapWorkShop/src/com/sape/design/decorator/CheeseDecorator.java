package com.sape.design.decorator;

import java.math.BigDecimal;

public class CheeseDecorator extends SandWichDecorator {

	Sandwich currentSandWich;
	public CheeseDecorator(Sandwich sw) {
		this.currentSandWich = sw;
	}
	
	@Override
	public String getDescription() {
		return currentSandWich.getDescription() + "Cheese";
	}
	
	public BigDecimal price() {
		return currentSandWich.price().add(new BigDecimal("0.50"));
	}
	
}
