package com.design;

public class Female extends Person { 
	public Female(String fullNname) {
		System.out.println("Hello Ms. "+fullNname);
	} 
}
