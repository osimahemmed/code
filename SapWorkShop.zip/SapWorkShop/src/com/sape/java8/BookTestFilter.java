package com.sape.java8;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class BookTestFilter {

	public static void main(String[] args) {
		
		List<Book> list = new ArrayList<Book>();
		
		//Collections.synchronizedMap(m)
		
		//List<Integer> a  = new Hashtable<Integer>();
		Map<String, Integer> map = new Hashtable<>();
		
		list.add(new Book("1","java", "PL"));
		list.add(new Book("2","c++",  "PL"));
		list.add(new Book("3","story", "Novel"));
		
		List<Book> list1 = list.parallelStream().filter(b->b.getCategory().equals("PL")).collect(Collectors.toList());
		list.parallelStream().filter(b->b.getCategory().equals("PL")).forEach(System.out::println);;
		
		/*for(Book b : list1) {
			System.out.println(b.getName()+ " "+ b.getCategory());
		}*/
		
		System.out.println(list1);

	}

}
