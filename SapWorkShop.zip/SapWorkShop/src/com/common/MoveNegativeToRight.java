package com.common;

import java.util.Arrays;

public class MoveNegativeToRight {
	
	static int[] segregateElements(int input[], int n)
	{
		// Create an empty array to store result
		int temp[] = new int[n];

		// Traversal array and store +ve element in
		// temp array
		int j = 0; // index of temp
		for (int i = 0; i < n ; i++)//1 ,-1 ,-3 , -2, 7, 5, 11, 6
			if (input[i] >= 0 )
				temp[j++] = input[i];

		// If array contains all positive or all negative.
		if (j == n || j == 0) {
			System.out.println("Returning null " + " j = "+j +" n = ");
			return temp;
		}
			
		System.out.println("Value of j " + j);
		// Store -ve element in temp array
		for (int i = 0 ; i < n ; i++)//1 ,-1 ,-3 , -2, 7, 5, 11, 6
			if (input[i] < 0)
				temp[j++] = input[i];

		// Copy contents of temp[] to arr[]
		
		//input = Arrays.copyOf(temp, input.length);
		
		return temp;	
	}


	public static void main(String[] args) {
		int arr[] = {1 ,-1 ,-3 , -2, 7, 5, 11, 6};
		int n = arr.length;

		arr = segregateElements(arr, n);
		
		for (int i = 0; i < n; i++)
			System.out.print(arr[i] +" ");
		
		/*int var1 = 5;
        int var2= 6;
        
        if((var2=1)==var1)
               System.out.println("var2 if block " +var2);
        else
               System.out.println(" var2 " +var2);
        
        
        byte x = 64;
        int i;
        byte y;
        i = x<<2;
        y = (byte)(x<<2);
        System.out.println("osim " +i+ " "+y);*/



			 
	}

}
