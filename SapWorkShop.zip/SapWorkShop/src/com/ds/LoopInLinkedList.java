package com.ds;

public class LoopInLinkedList {
	
	Node head;
	
	class Node {
		int data;
		Node next;
		public Node(int d) {
			data = d;
			next = null;
		}
	}
	
	private void push(int new_data) {
		Node new_node = new Node(new_data);
		new_node.next = head;
		head = new_node;
	}
	
	public int pop() {
		if(head == null) {
			System.out.println("head is null");
		}
		int value = head.data;
		head = head.next;
		return value;
	}
	
	public void printList() {
		Node tnode = head;
		System.out.println(tnode.data);
		tnode = tnode.next;
	}
	private int detectLoop() {
		Node slow_ptr = head, fast_ptr = head;
		while(slow_ptr != null && fast_ptr != null && fast_ptr.next != null) {
			slow_ptr = slow_ptr.next;
			fast_ptr = fast_ptr.next.next;
			if(slow_ptr == fast_ptr) {
				System.out.println("Found a loop " + slow_ptr.data);
				return 1;
			}
		}
		return 0;
	}
	public static void main(String[] args) {
		LoopInLinkedList list = new LoopInLinkedList();
		list.push(1);
		list.push(2);
		list.push(3);
		list.push(4);
		list.push(5);
		list.pop();
		list.head.next.next.next.next = list.head;
		list.detectLoop();
	}

}