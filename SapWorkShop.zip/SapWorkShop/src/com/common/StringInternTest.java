package com.common;

public class StringInternTest {

	public static void main(String[] args) {
		
		String s1 = new String("Morgan");
		String s2 = "Morgan";
		s1 = s1.intern();
		System.out.println(s1==s2);

	}

}
