package com.ds;

public class SpriralMatrixPrint {

	public static void main(String ...s){
		int[][] arr = new int[][]{{1,2,3,4},
								  {5,6,7,8},
								  {9,10,11,12},
								  {13,14,15,16}};
		int startCol = 0;
		int startRow = 0;
		int endRow = arr.length-1;
		int endCol = arr[0].length-1;
		char direction = 'R';
		//int count = 1;
		while(true) {
			//System.out.println("counter="+count++);
			if(startRow > endRow || startCol > endCol){
				break;
			}
			if(direction =='R'){
				printHorizontal(arr,startCol, endCol, startRow,1);
				startRow++;
				direction = 'D';
			}else if(direction == 'L'){
				printHorizontal(arr, endCol, startCol, endRow, -1);
				endRow--;
				direction = 'U';
			}else if(direction == 'D'){
				printVertical(arr,startRow, endRow, endCol,1);
				endCol--;
				direction = 'L';
			}else if(direction == 'U'){
				printVertical(arr,endRow, startRow, startCol,-1);
				startCol++;
				direction = 'R';
			}
		}
	}
	private static void printVertical(int[][] arr, int startRow, int endRow, int col, int d) {
		int indx = startRow;
		while(true){
			System.out.print(arr[indx][col]+"  ");
			indx = indx + d;
			if((d == 1 && indx>endRow)||(d==-1 && indx<endRow)){
				break;
			}
		}

	}
	private static void printHorizontal(int[][] arr, int startCol, int endCol, int row, int d) {
		int indx = startCol;
		while(true){
			System.out.print(arr[row][indx]+"  ");
			indx = indx + d;
			if((d == 1 && indx>endCol)||(d==-1 && indx<endCol)){
				break;
			}
		}

	}

	/*private static void method1(){
		int[][] arr = new int[][]{{1,2},{3,4}};
		int startX = 0;
		int startY = 0;
		int endY = arr.length;
		int endX= arr[0].length;

		int x = startX;
		int y = startY;
		char direction = 'R';
		while(startX<=endX || startY<=endY){
			System.out.print(arr[x][y]);
			if(direction == 'R'){
				if(x<endX){
					x++;
				}else if(x == endX){
					direction = 'D';
					startY++;
					y = startY;
				}

			}else if(direction =='D'){
				if(y<endY){
					y++;
				}else if(y == endY){
					direction = 'L';
					startX++;
					x = endX-1;
				}
			}else if(direction=='L'){
				if(x>startX){
					x--;
				}else if(x == startX){
					direction = 'U';
					endY--;
					y = endY;
				}
			}else if(direction == 'U'){
				if(y>startY){
					y--;
				}else if(y== startY){
					direction = 'R';
					startY--;
				}

			}
		}
	}*/
}
