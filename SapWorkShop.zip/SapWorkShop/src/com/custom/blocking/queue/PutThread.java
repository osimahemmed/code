package com.custom.blocking.queue;

public class PutThread implements Runnable {

	CustomBlockingQueue<Integer> custom;
	public PutThread(CustomBlockingQueue<Integer> custom) {
		this.custom = custom;
	}
	
	
	@Override
	public void run() {
		for(int i = 0; i <= 15; i++) {
			try {
				System.out.println("Putting elements " + i);
				custom.put(i);
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		try {
			custom.put(-1);
			System.out.println("osim " +custom.toString());
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	

}
