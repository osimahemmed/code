package com.hashcode.equal;

import java.util.Objects;

public class UserHashCodeJdk7 {
	
	private String name;
	private int age;
	private String passport;
	
	public UserHashCodeJdk7(String name, int age, String passport) {
		this.name = name;
		this.age = age;
		this.passport = passport;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getPassport() {
		return passport;
	}
	public void setPassport(String passport) {
		this.passport = passport;
	}
	
	@Override
	public boolean equals(Object o) {
		if(o == null)
			return false;
		if(o == this)
			return true;
		if(!(o instanceof UserHashCodeJdk7)) {
			return false;
		}
		UserHashCodeJdk7 user = (UserHashCodeJdk7) o;
		return age == user.age &&
				Objects.equals(name, user.name)&&
				Objects.equals(passport, user.passport);
	}
	@Override
	public int hashCode() {
		return Objects.hash(name,age,passport);
	}
	public static void main(String[] args) {
		UserHashCodeJdk7 user1 = new UserHashCodeJdk7("osim", 34, "1122");
		UserHashCodeJdk7 user2 = new UserHashCodeJdk7("osim", 34, "1122");
		System.out.println(user1.equals(user2));
	}
	

}
