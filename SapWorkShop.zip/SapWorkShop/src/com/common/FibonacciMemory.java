package com.common;

public class FibonacciMemory {
	static int[] arr = new int[Integer.MAX_VALUE];
	public static void main(String[] args) {
		
		//String s;
		for(int i = 0; i <arr.length;i++) {
			arr[i] = -1;
		}
		arr[0] = 0;
		arr[1] = 1;
		int a = Fib(8);
		System.out.println(a);

	}
	
	static int Fib(int n) {
		/*if(n<=1) {
			return n;
		}*/
		if(arr[n] != -1) {
			return arr[n];
		}
		arr[n] = Fib(n-1)+Fib(n-2);
		return arr[n];
	}

}
