package com.common;

import java.util.HashSet;
import java.util.Set;


public class RemoveDupsFromUnsortedLinkedList {
	
	Node head;
	class Node {
		int data;
		Node next;
		public Node(int data) {
			this.data = data;
		}
	}
	
	Node curr = null;
	private void push(int new_data) {
		Node new_node = new Node(new_data);
		if(head == null) {
			head = new_node;
			curr = head;
		} else {
			curr.next = new_node;
			curr = curr.next;
		}
	}
	
	private void printList(Node head) {
		while(head != null) {
			System.out.printf(" %d " , head.data);
			head = head.next;
		}
	}

	public static void main(String[] args) {
		RemoveDupsFromUnsortedLinkedList list = new RemoveDupsFromUnsortedLinkedList();
		list.push(1);
		list.push(5);
		list.push(3);
		list.push(1);
		list.push(4);
		list.push(3);
		list.push(4);
		list.push(4);
		list.push(4);
		list.printList(list.head);
		Node temp = list.removeDuplicates(list.head);
		System.out.println();
		list.printList(temp);
	}

	private Node removeDuplicates(Node head) {//1 5 3 1 4 3 4
		if(head == null)
			return null;
		Node previous = null;
		Node current = head;
		Set<Integer> set = new HashSet<>();
		
		while(current != null) {
			if(set.contains(current.data)) {
				previous.next = current.next;
				//set.remove(current.data);
				
			} else {
				set.add(current.data);
				previous = current;
			}
			current = previous.next;
		}
		
		return head;
	}

}
