package com.collection;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class EmployeeMapTest {

	public static void main(String[] args) {
		
		Employee emp1 = new Employee(11, "Mark");
		Employee emp2 = new Employee(12, "Steve");
		Employee emp3 = new Employee(13, "Swapan");
		Employee emp4 = new Employee(14, "Osim");
		Employee emp5 = new Employee(15, "Sushil");
		
		Map<Employee, String> map = new HashMap<Employee, String>();
		map.put(emp1, "emp1");
		map.put(emp2, "emp2");
		map.put(emp3, "emp3");
		map.put(emp4, "emp4");
		map.put(emp5, "emp5");
		
		//System.out.println(map);
		
		Set<Employee> keys = map.keySet();
		for(Employee emp : keys) {
			System.out.println(emp+ "-> " + map.get(emp));
		}

	}

}
