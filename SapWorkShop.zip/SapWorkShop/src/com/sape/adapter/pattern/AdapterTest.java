package com.sape.adapter.pattern;

public class AdapterTest {

	public static void main(String[] args) {
		Sparrow sparrow = new Sparrow();
		PlatsicToyDuck toyDuck = new PlatsicToyDuck();
		
		// Wrap a bird in a birdAdapter so that it 
        // behaves like toy duck
		IToyDuck birdAdapter = new BirdAdapter(sparrow);
		System.out.println("Sparrow.... ");
		sparrow.fly();
		sparrow.makeSound();
		
		System.out.println("Toy Duck ...");
		toyDuck.squeak();
		
		// bird behaving like a toy duck
		System.out.println("Bird adapter");
		birdAdapter.squeak();

	}

}
