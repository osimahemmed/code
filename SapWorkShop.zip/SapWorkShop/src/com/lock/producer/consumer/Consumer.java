package com.lock.producer.consumer;

import java.util.NoSuchElementException;
import java.util.Queue;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class Consumer extends Thread {
	
	private Lock lock;
	private Condition prdCon;
	private Condition conCon;
	private Queue<Integer> queue;
	
	public Consumer(Lock lock, Condition prdCon, Condition conCon , Queue<Integer> queue) {
		this.lock = lock;
		this.prdCon = prdCon;
		this.conCon = conCon;
		this.queue = queue;
	}
	
	@Override
	public void run() {
		for(int i = 0; i < 10; i++) {
			lock.lock();
			while(queue.size() == 0) {
				try {
					conCon.await();
				} catch (InterruptedException e) {
					System.out.println(e.getMessage());
				}
			}
			try {
				System.out.println("Consumed " + queue.remove());
				prdCon.signal();
			} catch (NoSuchElementException | IllegalMonitorStateException e) {
				System.out.println(e.getMessage());
			} finally {
				lock.unlock();
			}
		}
	}

}
