package com.ds;

public class LinkedListDeletionGreaterThanGivenNum {
	
	Node head;
	
	class Node {
		int data;
		Node next;
		Node(int d) {
			data = d;
			next = null;
		}
	}

	/*void printMiddle() {
		Node slow_ptr = head;
		Node fast_ptr= head;
		 if(head !=null) {
			 while(fast_ptr != null && fast_ptr.next != null) {
				 fast_ptr = fast_ptr.next.next;
				 slow_ptr = slow_ptr.next;
			 }
			 System.out.println("Middle element is " + slow_ptr.data);
		 }
		
	}*/
	
	Node curr;
	public void push(int new_data) {
		/*Node new_node = new Node(new_data);
		new_node.next = head;
		head = new_node;*/
		Node new_node = new Node(new_data);
		if(head == null) {
			head = new_node;
			curr = head;
		} else {
			curr.next = new_node;
			curr = curr.next;
		}
		
		
	}
	
	private Node removeNodes() {

		Node start = head;
		int x = 5;
		if(start == null) return start;

		if(start.data > x && start.next == null) 
			return null;

		//find first head node
		Node curr = start;
		Node prev = null;

		//4,5,3,2,1,6 --- where x = 2
		while(curr != null && curr.data > x) {
		    prev = curr;
		    curr = curr.next;
		}

		if(prev != null) 
			prev.next = null;

		Node newHead = curr;

		while(curr.next != null) {
		    if(curr.next.data > x) {
		        curr.next = curr.next.next;
		    } else {
		        curr = curr.next;
		    }
		}

		return newHead;
		}

	
	public void printList() {
		Node tNode = head;
		while(tNode != null) {
			System.out.println(tNode.data + "-->");
			tNode = tNode.next;
		}
		//System.out.println("Null");
	}
	
	public static void main(String[] args) {
		LinkedListDeletionGreaterThanGivenNum list = new LinkedListDeletionGreaterThanGivenNum();
		//for(int i = 10; i > 0; --i) {
			list.push(13);
			list.push(10);
			list.push(3);
			list.push(15);
			list.push(6);
			list.push(4);
			list.push(2);
			list.push(5);
			
			//list.printMiddle();
		//}
		list.removeNodes();
		list.printList();

	}
}
