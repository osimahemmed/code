package com.sape.lock.producer.consumer;

public class Consumer extends Thread {

	ProducerConsumerImpl pc;
	
	public Consumer(ProducerConsumerImpl pc) {
		super("CONSUMER");
		this.pc = pc;
	}
	
	public void run() {
		try {
			pc.get();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
