package com.sape.multiconsumer;

import java.util.concurrent.BlockingQueue;

public class Producer implements Runnable {
	private BlockingQueue<Integer> queue;
	private String threadName;
	
	public Producer(BlockingQueue<Integer> queue) {
		this.queue = queue;
	}
	
	@Override
	public void run() {
		threadName = Thread.currentThread().getName();
		try {
			for(int i=0; i<10;i++) {
				queue.put(produce());
				Thread.sleep(1000);
			}
			queue.put(-1);
			System.out.println(threadName +" Producer stopped");
		} catch (InterruptedException ie) {
			ie.printStackTrace();
		}
		
	}
	
	private Integer produce() {
		Integer number = new Integer((int)(Math.random() * 100));
		System.out.println(threadName +" Producing Number  " + number);
		return number;
	}

}
