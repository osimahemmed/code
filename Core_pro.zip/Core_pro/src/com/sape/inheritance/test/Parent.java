package com.sape.inheritance.test;

public class Parent {
	
	private String a = "Hi";
	public String b = "Hi 1";
	protected String c = "Hi 2";
	
	String d = "Hi 3";
	
	static String e = "Hi 4";
	
	public static void main(String[] args) { 
		
	}

}
