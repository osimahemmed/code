package com.sape.concurrent.cyclicbarrier;

public class WaitNotifyCycliExample {

    public static void main(String[] args) {

           Object firstLock = new Object();
           Object secondLock = new Object();
           Object thirdLock = new Object();
           Object fourthLock = new Object();

           Object[] a1 = new Object[] { 1, 5, 9, 13, 17 };
           Object[] a2 = new Object[] { 2, 6, 10, 14, 18 };
           Object[] a3 = new Object[] { 3, 7, 11, 15, 19 };
           Object[] a4 = new Object[] { 4, 8, 12, 16, 20 };

           Thread t1 = new Thread(new CycliceRunnable(a1, firstLock, secondLock));
           Thread t2 = new Thread(new CycliceRunnable(a2, secondLock, thirdLock));
           Thread t3 = new Thread(new CycliceRunnable(a3, thirdLock, fourthLock));
           Thread t4 = new Thread(new CycliceRunnable(a4, fourthLock, firstLock));
           
           t1.start();
           t2.start();
           t3.start();
           t4.start();

           synchronized (firstLock) {
                  firstLock.notify();
           }
    }

}

class CycliceRunnable implements Runnable {
    final Object[] array;
    final Object waitLock;
    final Object notifyLock;

    public CycliceRunnable(Object[] array, Object waitLock, Object notifyLock) {
           this.waitLock = waitLock;
           this.notifyLock = notifyLock;
           this.array = array;
    }

    public void run() {
           try {
                  for (int i = 0; i < array.length; i++) {
                        synchronized (waitLock) {
                        	System.out.println("Waiting " + Thread.currentThread().getName());
                               waitLock.wait();
                        }
                        System.out.println("Thread Name" + Thread.currentThread().getName() + ":: " + array[i]);
                        synchronized (notifyLock) {
                               notifyLock.notify();
                        }
                  }

           } catch (InterruptedException e) {
                  e.printStackTrace();
           }
    }
}

