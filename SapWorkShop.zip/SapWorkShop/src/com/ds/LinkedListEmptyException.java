package com.ds;

public class LinkedListEmptyException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8246420812243294595L;
	
	public LinkedListEmptyException() {
		super();
	}
	public LinkedListEmptyException(String message) {
		super(message);
	}

}
