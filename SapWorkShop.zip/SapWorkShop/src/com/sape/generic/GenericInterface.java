package com.sape.generic;

public interface GenericInterface<T> {
	void setT(T t);
	T getT();
}
