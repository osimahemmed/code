package com.osim.java8;

@FunctionalInterface
public interface StringConcat {

	public String sconcat(String str1, String str2); 
	
}
