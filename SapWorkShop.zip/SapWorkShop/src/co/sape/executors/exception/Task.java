package co.sape.executors.exception;

public class Task implements Runnable {

	@Override
	public void run() {
		
		throw new NullPointerException();
		
	}

}
