package com.sape.checked.exception;

public class CustomerService {

	public Customer findByName(String name) throws NameNotFoundException {

        if ("".equals(name)) {
            throw new NameNotFoundException("Name is empty!");
        }

        return new Customer(name);

    } 
	public static void main(String[] args) {
		CustomerService obj = new CustomerService();

        try {

            Customer cus = obj.findByName("");
            System.out.println(cus.getName());

        } catch (NameNotFoundException e) {
        	System.out.println("Getting exception for Customer === " + e.getMessage());
            e.printStackTrace();
        }

	}

}
