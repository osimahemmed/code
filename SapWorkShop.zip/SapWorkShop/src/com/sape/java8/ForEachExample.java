package com.sape.java8;

import java.util.HashMap;
import java.util.Map;

public class ForEachExample {

	public static void main(String[] args) {
		
		Map<String, Integer> items = new HashMap<String, Integer>();
		
		items.put("A", 10);
		items.put("B", 20);
		items.put("C", 30);
		items.put("D", 40);
		items.put("E", 50);
		items.put("F", 60);
		
		items.forEach((K, V) -> System.out.println("Item : " + K + " Count : " + V));

	}

}
