package com.common;

import java.util.HashMap;
import java.util.Map;

public class CompressStringWithStar {

	public static void main(String[] args) {
		String str = "ABABCABABCD";
		Map<String, Integer> map = new HashMap<String, Integer>();
		String output = "";
		
		for(int i = 0; i < str.length(); i++) {
			if(output.contains(""+str.charAt(i))) {
				output = output + "*";
			} else {
				output += str.charAt(i);
			}
		}
		
		System.out.println(output);

	}

}
