package com.mulitiple.prd.consumer;

public class BufferProducer implements Runnable {

	Buffer buffer;

	public BufferProducer(Buffer buffer) {
		this.buffer = buffer;
	}

	@Override
	public void run() {
		for (int i = 1; i <= 10; i++) {
			buffer.put(i);
		}
	}
	
	Thread thread;
}
