package com.sape.design.command;

public class UnixFileSystemReceiver implements FileSystemReceiver {

	@Override
	public void openFile() {
		System.out.println("Openng file in unix");
		
	}

	@Override
	public void writeFile() {
		System.out.println("writing file in unix");
		
	}

	@Override
	public void closeFile() {
		System.out.println("closing file in unix");
		
	}

}
