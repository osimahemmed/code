
/* 
 Input : 
        1
      /   \
     2     3
    / \   / \
   4   5 6   7
          \
           8
 */

package com.ds;

public class SumOfNodesOfBinaryTree {
	
	static class Node {
		
		int data;
		Node left, right ;
		
		public Node(int d) {
			this.data = d;
			left = right = null;
		}
		
	}
	
	static int sum(Node root) {
		int sum = 0;
		if(root == null) {
			return 0;
		}
		sum = sum + root.data +
				sum(root.left) +
				sum(root.right);
		
		
		return sum;
		
	}
	//sum of leaf nodes of binary tree
	static int sum = 0;
	static int leafNodeSum(Node root) {
		if(root == null) {
			return 0;
		}
		if(root.left == null && root.right == null) {
			System.out.print(" "+ root.data);
			sum = sum + root.data;
		}
		leafNodeSum(root.left);
		leafNodeSum(root.right);
		
		return sum;
	}

	public static void main(String[] args) {
		Node root = new Node(1);
		root.left = new Node(2);
		root.left.left = new Node(4);
		root.left.right = new Node(5);
		root.right = new Node(3);
		root.right.right = new Node(7);
		root.right.left = new Node(6);
		root.right.left.right = new Node(8);
		int res = sum(root);
		System.out.println("Sum of all nodes "+res);
		int leafSum  =leafNodeSum(root);
		System.out.println("Leaf Node sum " + leafSum);

	}

}
