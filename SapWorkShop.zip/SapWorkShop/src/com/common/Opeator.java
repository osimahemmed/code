package com.common;

public class Opeator {

	public static void main(String[] args) {
		char[] arr = {'h','e','l','l','o', '.'};
		String str = new String(arr);
		System.out.println(str);
		System.currentTimeMillis();
	}

}
