package com.sape.adapter.pattern;

public class PlatsicToyDuck implements IToyDuck {

	@Override
	public void squeak() {
		System.out.println("squeak");

	}

}
