package com.sape.lambda;

import java.util.Arrays;
import java.util.List;

public class Unit1Exercise {

	public static void main(String[] args) {
		
		List<Person> people = Arrays.asList(
				new Person("osim", "ahemmed", 20),
				new Person("Abhi", "khanna", 24),
				new Person("jack", "boslin", 39),
				new Person("monica", "khan", 12),
				new Person("swapan", "kumar", 19)
				);
		
		System.out.println("using for loop");
		for(int i=0;i<people.size();i++) {
			System.out.println(people.get(i));
		}
		/*System.out.println("using for in");
		for(Person p : people) {
			System.out.println(p);
		}*/
		System.out.println("using lambda for each");
		people.forEach(p -> System.out.println(p));
		//people.forEach(System.out::println);
		
	}
}
