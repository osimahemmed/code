package com.java.lamda;

public class Java8 {

	public static void main(String[] args) {
		
		IGreetingService service2 = message -> System.out.println("Hello "+ message);

		service2.sayMessage("osim");
	}

}
