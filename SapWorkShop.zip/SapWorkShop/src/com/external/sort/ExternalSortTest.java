package com.external.sort;

import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ExternalSortTest {

	private static final String TEST_FILE = "test-file.txt";
	private static final String TEST_FILE1 = "test-file1.txt";
	private static final String TEST_FILE2 = "test-file2.txt";

	private static final String[] EXPECTED_SORT_RESULTS = { "a", "b", "b", "e", "f","i", "m", "o", "u", "u", "x", "y", "z"};
	private static final String[] EXPECTED_MERGE_RESULTS = {"a", "a", "b", "c", "c", "d", "e", "e", "f", "g", "g","h", "i", "j", "k"};
	private static final String[] SAMPLE = { "f", "m", "b", "e", "i", "o", "u","x", "a", "y", "z", "b", "u"};

	private File file;
	private File file1;
	private File file2;
	private List<File> fileList;

	@Before
	public void setUp() throws Exception {
		this.fileList = new ArrayList<File>(3);
		this.file = new File(TEST_FILE);

		this.file1 = new File(TEST_FILE1);
		this.file2 = new File(TEST_FILE2);

		File tmpFile1 = new File(TEST_FILE1+".tmp");
		File tmpFile2 = new File(TEST_FILE2+".tmp");

		copyFile(this.file1, tmpFile1);
		copyFile(this.file2, tmpFile2);

		this.fileList.add(tmpFile1);
		this.fileList.add(tmpFile2);
	}

	@After
	public void tearDown() throws Exception {
		this.file = null;
		for(File f:this.fileList) {
			f.delete();
		}
		this.fileList.clear();
		this.fileList = null;
	}

	@Test
	public void testSortInBatch() throws Exception {
		Comparator<String> cmp = new Comparator<String>() {
			@Override
			public int compare(String o1, String o2) {
				return o1.compareTo(o2);
			}
		};

		List<File> listOfFiles = ExternalSort.filesChunks(this.file, cmp, 1024,null);
		assertEquals(1, listOfFiles.size());
	}

	@Test
	public void testMergeSortedFiles() throws Exception {
		String line;

		Comparator<String> cmp = new Comparator<String>() {
			@Override
			public int compare(String o1, String o2) {
				return o1.compareTo(o2);
			}
		};

		File out = File.createTempFile("merge_results", ".txt", new File("D:\\external_sorting"));
		//		out.deleteOnExit();
		ExternalSort.mergeFiles(this.fileList, out, cmp);

		List<String> result = new ArrayList<>();
		try (BufferedReader bf = new BufferedReader(new FileReader(out))) {
			while ((line = bf.readLine()) != null) {
				result.add(line);
			}
		}
		assertArrayEquals(Arrays.toString(result.toArray()), EXPECTED_MERGE_RESULTS,result.toArray());
	}

	@Test
	public void testSortAndSave() throws Exception {
		File f;
		String line;

		List<String> sample = Arrays.asList(SAMPLE);

		Comparator<String> cmp = new Comparator<String>() {
			@Override
			public int compare(String o1, String o2) {
				return o1.compareTo(o2);
			}
		};

		f = ExternalSort.sortAndSave(sample, cmp,new File("D:\\external_sorting"));

		assertNotNull(f);
		assertTrue(f.exists());
		assertTrue(f.length() > 0);
		List<String> result = new ArrayList<>();

		try (BufferedReader bufferedReader = new BufferedReader(new FileReader(f))) {
			while ((line = bufferedReader.readLine()) != null) {
				result.add(line);
			}
		}
		assertArrayEquals(Arrays.toString(result.toArray()), EXPECTED_SORT_RESULTS,result.toArray());
	}

	private static void copyFile(File sourceFile, File destFile) throws IOException {
		if (!destFile.exists()) {
			destFile.createNewFile();
		}

		try (FileInputStream fis = new FileInputStream(sourceFile);
				FileChannel source = fis.getChannel();
				FileOutputStream fos = new FileOutputStream(destFile);
				FileChannel destination = fos.getChannel()) {
			destination.transferFrom(source, 0, source.size());
		}
	}
}
