/* Java String Compare
Given a string, find out the lexicographically smallest and largest substring of length k.
[Note: Lexicographic order is also known as alphabetic order dictionary order. So "ball" is smaller than "cat", "dog" is smaller 
than "dorm". Capital letter always comes before smaller letter, so "Happy" is smaller than "happy" and "Zoo" is smaller than 
"ball".]
Input Format
First line will consist a string containing english alphabets which has at most 1000 characters. 
2nd line will consist an integer k.
Output Format
In the first line print the lexicographically minimum substring. In the second line print the lexicographically maximum substring.
*/


package com.common;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class StringCompareSmallestLargest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		//String inputString = sc.nextLine();
		//int length = sc.nextInt();
		List<String> list = new ArrayList<String>();
		int length = 3;
		String inputString = "welcometojavaworld";
		String smallest="";
		String largest="";
		long startTime = System.currentTimeMillis();
		for(int i = 0;i <= inputString.length()-length; i++) {
			String subString = inputString.substring(i, i + length);
			list.add(subString);
			if(i == 0) {
				smallest = subString;
			}
			if(subString.compareTo(largest) > 0) {
				largest = subString;
			} else if(subString.compareTo(smallest) < 0)
				smallest = subString;
		}
		
		//System.out.println(list);
		//Collections.max(list);
		System.out.println(Collections.max(list));
		System.out.println(Collections.min(list));
		/*Collections.sort(list);
		System.out.println(list.get(0) + "  "+ list.get(list.size()-1));
		System.out.println(list);*/
		//System.out.println(smallest);
		//System.out.println(largest);
		long endTime = System.currentTimeMillis();
		
		System.out.println("diffence "+ (endTime-startTime));
		//sc.close();

		
	}

}
