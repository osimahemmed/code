package com.ds;

import java.util.Queue;

public class SearchElementInTree {
	
	static class Node {
		int data;
		Node left, right;
		
		public Node(int data) {
			this.data = data;
		}
	}

	private static boolean isPresent(Node root, int x) {
		if(root == null)
			return false;
		if(root.data == x) {
			return true;
		} else {
			return isPresent(root.left, x) || isPresent(root.right, x);
		}
	}
	
	private static boolean isPresentIterative(Node root, int x) {
		if(root == null)
			return false;
		Queue<Node> queue = new java.util.LinkedList<>();
		queue.add(root);
		
		while(!queue.isEmpty()) {
			Node temp = queue.poll();
			if(temp.data == x) {
				return true;
			}
			if(temp.left != null) {
				queue.add(temp.left);
			}
			if(temp.right != null) {
				queue.add(temp.right);
			}
		}
		
		return false;
		
	}
	
	public static void main(String[] args) {
		Node root = new Node(10);
		root.left = new Node(15);
		root.right = new Node(20);
		root.left.left = new Node(6);
		root.left.right = new Node(8);
		root.right.left = new Node(34);
		root.right.right = new Node(36);
		
		System.out.println("is the element present in tree " + isPresent(root, 100));
		System.out.println("is the element present in tree using iterative way " + isPresentIterative(root, 100));

	}

}
