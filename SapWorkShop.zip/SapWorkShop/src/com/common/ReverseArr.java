package com.common;

import java.util.Arrays;

public class ReverseArr {

	public static void main(String[] args) {
		
		String[] names = {"John", "Jammy", "Luke","Osim","Swapan"};
        System.out.println("original array: " + Arrays.toString(names) );
       
        reverse(names);
        System.out.println("reversed array: " + Arrays.toString(names) );
	}
	
	private static void reverse(String[] arr) {
		if(null == arr || arr.length < 2) 
			return;
		for(int i = 0; i < arr.length/2; i++) {
			String temp = arr[i];
			arr[i] = arr[arr.length-1-i];
			arr[arr.length-1-i] = temp;
		}
		
	}
}
