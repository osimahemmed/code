package com.ds;

public class SubclassNotInherit {
	
	public int val = 10;
	
	public SubclassNotInherit() {
		if(this.getClass() != SubclassNotInherit.class) {
			throw new RuntimeException("subclass cannot be allowed");
		}
	}
	
	public void test() {
		System.out.println("Hello test in super class");
	}

}
