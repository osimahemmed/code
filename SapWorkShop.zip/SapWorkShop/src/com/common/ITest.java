package com.common;

public interface ITest {
	void test();

}
