package com.design;

public class TestJ {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		String str = "343242er=trest:2345h";
		
		System.out.println(str.substring(str.indexOf(":")+1, str.length()));

	}

}
