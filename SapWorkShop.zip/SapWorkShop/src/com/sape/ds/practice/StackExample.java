package com.sape.ds.practice;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class StackExample {

	public static void main(String[] args) {
		Queue<Integer> stack = new LinkedList<Integer>();
		stack.add(1);
		stack.add(4);
		stack.add(7);
		stack.add(0);
		System.out.println(stack.element());
		System.out.println(stack);
		System.out.println(stack);
		

	}

}
