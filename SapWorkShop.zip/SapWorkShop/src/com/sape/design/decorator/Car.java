package com.sape.design.decorator;

public interface Car {
	public void assemble();
}
