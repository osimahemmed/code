package com.sape.adapter.design;

public class AppleAdapter implements Chargeable {

	Charger samsungCharger;

	public void setSamsungCharger(Charger samsungCharger) {
		this.samsungCharger = samsungCharger;
	}

	@Override
	public void setMobileName(String mobileName) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void charge() {
		samsungCharger.supplyCharge();
		
	}

}
