package com.sape.prd.consumer;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

public class ProducerConsumerDemo {

	public static void main(String[] args) {
		AtomicInteger atomicInt = new AtomicInteger(1);
		BlockingQueue<Integer> sharedQueue = new LinkedBlockingQueue<Integer>();
		
		Thread prodThread1 = new Thread(new Producer(sharedQueue,atomicInt), "prodThread1");
		Thread prodThread2 = new Thread(new Producer(sharedQueue,atomicInt), "prodThread2");
		Thread consThread1 = new Thread(new Consumer(sharedQueue), "consThread1");
		Thread consThread2 = new Thread(new Consumer(sharedQueue), "consThread2");
		
		prodThread1.start();
		prodThread2.start();
		consThread1.start();
		consThread2.start();
	}

}
