package com.common;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public final class ImmutableClass {

	private final String countryName;
	private final List<String> listOfStates1;
	private final Date mutableField1;

	//Default private constructor will ensure no unplanned construction of class
	private ImmutableClass(String countryName, ArrayList<String> listOfStates, Date mutableField) {
		//super();
		this.countryName = countryName;
		this.mutableField1 = new Date(mutableField.getTime());
		//ArrayList<String> tempList = new ArrayList<String>(listOfStates);
		this.listOfStates1 = new ArrayList<String>(listOfStates);
		//this.listOfStates1 = tempList;
	}
	
	public static ImmutableClass createNewInstancle(String countryName, ArrayList<String> listOfStates, Date mutableDate) {
		return new ImmutableClass(countryName, listOfStates, mutableDate);
	}

	public String getCountryName() {
		return countryName;
	}
	
	public Date getMutableFiled() {
		return new Date(mutableField1.getTime());
	}

	@SuppressWarnings("unchecked")
	public List<String> getListOfStates() {
		//return (ArrayList<String>) listOfStates.clone();
		return new ArrayList<String>(listOfStates1);
		
		//List<String> list1 = new ArrayList<String>(listOfStates);
		//return list1;
	}
	
	public String toString() {
		return listOfStates1 + " - " + countryName + " - " + mutableField1;
	}



	public static void main(String args[]) {   
		ArrayList<String> listOfStates = new ArrayList<String>();  
		
		String name = "Hello";
		//sysooutname.concat("")
		System.out.println(name.concat("World"));
		
		//Collections.unmodifiableList(listOfStates);
		listOfStates.add("Madhya Pradesh");   
		listOfStates.add("Maharastra");   
		listOfStates.add("Gujrat");   
		String countryName = "India";   
		ImmutableClass state = new ImmutableClass(countryName, listOfStates, new Date());  
		System.out.println("Country : " + state.getCountryName());   
		// Lets try to change local variable countryName   
		countryName = "China";   
		System.out.println("Updated Country : " + state.getCountryName());   
		System.out.println("List of states : " + state.getListOfStates());   
		   
		state.getListOfStates().add("Kerala");   
		// It will not be added to the list because we are using deep copy in   
		// constructor   
		listOfStates.add("Rajasthan");
		System.out.println("Updated List of states : " + state.getListOfStates());   

	}   

}
