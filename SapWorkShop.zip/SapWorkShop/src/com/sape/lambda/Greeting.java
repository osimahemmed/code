package com.sape.lambda;

@FunctionalInterface
public interface Greeting {
	void perform();
}

