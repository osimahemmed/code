package com.common;

public class StaticTest {

	   static int num;
	   static String mystr;
	   static{
	      num = 97;
	      System.out.println("static value osim = " + num);
	      mystr = "Static keyword in Java";
	   }
	   
	   {
		   num = 100;
		   System.out.println("instance block num = " +num);
	   }
	   
	   public static void main(String args[])
	   {
		  new StaticTest();
	      //System.out.println("Value of num= "+num);
	      System.out.println("Value of mystring = "+mystr);
	      
	   }
	   
	   public StaticTest() {
			System.out.println("Inside constructor");
		}

}
