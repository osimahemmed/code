package com.common;

public class RemoveConsecutiveChar {

	public static void main(String[] args) {
		String str = "Stooooopppppped";
		StringBuilder sb = new StringBuilder();
		char first = str.charAt(0);
		sb.append(first);
		for(int i=1;i<str.length();i++) {
			char ch = str.charAt(i);
			if(ch != first) {
				sb.append(ch);
			}
			first = ch;
		}

		System.out.println(sb.toString());
	}

}
