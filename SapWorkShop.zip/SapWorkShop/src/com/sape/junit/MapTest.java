package com.sape.junit;

import java.util.ConcurrentModificationException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.*;

public class MapTest {
	
	/*@Test
	public void testAssertMap() {
		Map<String, Integer> map = new HashMap<>();
		
		assertTrue(map.isEmpty());
	}*/
	
	@Test
	public void equalsTest() {
		HashMap<String, String> map1 = new HashMap<>();
		map1.put("a", "one");
        map1.put("b", "two");
        map1.put("c", "three");

        HashMap<String, String> map2 = new HashMap<>();
        map2.put("a", "one");
        map2.put("b", "two");
        map2.put("c", "three");
        
        assertTrue(map1.equals(map2));
        map2.put("c", "four");
        assertFalse(map1.equals(map2));
        
        map1.put("c", null);
        assertFalse(map1.equals(map2));
        
        map2.put("c", null);
        assertTrue(map1.equals(map2));
        map2.put("d", "four");
        System.out.println(" map2 : "+map2);
        System.out.println(" map1 : "+map1);
        assertFalse(map1.equals(map2));
        
	}
	
	@Test
    public void iteratorTest() {
        HashMap<String, Object> map = new HashMap<>();
        map.put("font", "Verdana 11");
        map.put("colors", "#ff0000");

        Iterator<String> iterator = map.keySet().iterator();
        while (iterator.hasNext()) {
            String key = iterator.next();
            System.out.println(key);
        }
    }
	
	@Test
    public void iteratorConcurrentModificationTest() {
        HashMap<Integer, Integer> map = new HashMap<>();

        map.put(1, 1);
        map.put(2, 2);
        Iterator<Integer> iter = map.keySet().iterator();
        iter.next();
        map.put(3, 3);
        try {
            iter.next();
            fail("Expecting " + ConcurrentModificationException.class);
        } catch (ConcurrentModificationException ex) {
            // expecting this
        	ex.printStackTrace();
        }
    }
	
	private static int LOAD_COUNT = 50000;

    @Test
    public void pivotHashMapSpeedTest() {
        long t0 = System.currentTimeMillis();
        HashMap<Integer, Integer> map = new HashMap<>();
        for (int i = 0; i < LOAD_COUNT; i++) {
            map.put(Integer.valueOf(i), Integer.valueOf(i));
        }
        long t1 = System.currentTimeMillis();
        System.out.println("org.apache.pivot.HashMap " + (t1 - t0) + "ms");
    }
	
	@Test
    public void javaHashMapSpeedTest() {
        long t0 = System.currentTimeMillis();
        java.util.HashMap<Integer, Integer> map = new java.util.HashMap<>();
        for (int i = 0; i < LOAD_COUNT; i++) {
            map.put(Integer.valueOf(i), Integer.valueOf(i));
        }
        long t1 = System.currentTimeMillis();
        System.out.println("java.util.HashMap " + (t1 - t0) + "ms");
    }
}
