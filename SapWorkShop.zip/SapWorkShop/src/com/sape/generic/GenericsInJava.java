package com.sape.generic;

import java.util.ArrayList;

public class GenericsInJava
{
    public static void main(String[] args)
    {
        ArrayList<String> list = new ArrayList<String>();
 
        list.add("JAVA");
 
       // list.add(123);
 
        for (String str : list)
        {
            //Below statement throws ClassCastException at run time
 
            System.out.println(str);
        }
    }
}