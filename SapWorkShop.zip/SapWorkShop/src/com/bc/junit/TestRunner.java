package com.bc.junit;

import org.junit.runner.RunWith;

public class TestRunner {
	
	

}
