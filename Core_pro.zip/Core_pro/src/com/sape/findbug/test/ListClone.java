package com.sape.findbug.test;

import java.util.ArrayList;
import java.util.List;

public class ListClone {

	public static void main(String a[]){
        ArrayList<String> arrl = new ArrayList<String>();
        List<Person> listPerson = new ArrayList<>();
        listPerson.add(new Person("osim", "BLR"));
        listPerson.add(new Person("vinay", "PNB"));
        //adding elements to the end
        arrl.add("First");
        arrl.add("Second");
        arrl.add("Third");
        arrl.add("Random");
        System.out.println("Actual ArrayList:"+arrl);
        ArrayList<Person> list1 = (ArrayList<Person>) ((ArrayList<Person>) listPerson).clone();
        ArrayList<String> copy = (ArrayList<String>) arrl.clone();
        System.out.println("Cloned ArrayList:"+list1);
    }

}
