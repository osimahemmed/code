package com.sape.lambda;

public class HelloWorldGreeting implements Greeting {

	@Override
	public void perform() {
		System.out.println("Welcome Ulem-e Deoband");
		
	}
	
}
