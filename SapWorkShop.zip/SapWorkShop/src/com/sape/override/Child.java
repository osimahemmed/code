package com.sape.override;

import java.io.IOException;

class Child extends Parent
{
    //@Override
	public void show(String s) throws RuntimeException
    {
        System.out.println("Inside child method");
    }
	
	//@Override
	void m1(Double i)  {
		System.out.println("child of m1");
	}
	
	/*public static void main(String[] args) throws IOException {
		Parent c = new Child();
		c.m1(10);
	}*/
}
