package com.sape.adapter.design;

public class ChargerUtils {
	
	public static void doCharge(Chargeable charger) {
		charger.charge();
	}

}
