package com.common;

public class RemoveAdjacentCharInString {

	public static void main(String[] args) {
		String s = "ABCCBCBA";
		char[] str = s.toCharArray();
		RemoveAdjacentCharInString remove = new RemoveAdjacentCharInString();
		remove.removeAdjacentArray(str);
		System.out.println(str);

	}
	
	public void removeAdjacentArray(char[] str) {
		int j = 0;
		for(int i = 1; i <= str.length-1; i++) {
			while((str[i] == str[j]) && (j >= 0)) {
				i++;
				j--;
			}
			str[++j] = str[i];
		}
		return;
	}

}
