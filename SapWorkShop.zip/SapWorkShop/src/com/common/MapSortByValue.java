package com.common;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class MapSortByValue {

	public static void main(String a[]) {
		
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("A", 20);
		map.put("B", 45);
		map.put("C", 2);
		map.put("D", 67);
		map.put("E", 26);
		map.put("F", 93);
		map.put("G", 67);
		
		Collection<Integer> listValues = map.values();
		//Iterator<Integer> = listValues.iterator();
		System.out.println("listvalues " + listValues);
		
		Set<Entry<String, Integer>> set1 = map.entrySet();
		List<Entry<String, Integer>> list1 = new ArrayList<>(set1);
		
		Collections.sort(list1, new Comparator<Entry<String, Integer>>() {
			public int compare(Entry<String, Integer> s1, Entry<String, Integer> s2) {
				return s1.getValue().compareTo(s2.getValue());
			}
			
		});
		
		Map<String, Integer> linkMap = new LinkedHashMap<>();
		for(Entry<String, Integer> entry : list1) {
			linkMap.put(entry.getKey(), entry.getValue());
		}
		
		System.out.println(" osim "+linkMap);
		
		/*Set<Entry<String, Integer>> set = map.entrySet();
		List<Entry<String, Integer>> list = new ArrayList<>(set);
		
		Collections.sort(list, new Comparator<Entry<String, Integer>>(){
			@Override	
			public int compare(Entry<String, Integer> s1, Entry<String, Integer> s2) {
				return s1.getValue().compareTo(s2.getValue());
			}
		});
		
		Map<String, Integer> linkedHashMap = new LinkedHashMap<>();
		for(Entry<String, Integer> entry : list) {
			linkedHashMap.put(entry.getKey(), entry.getValue());
		}
		System.out.println(linkedHashMap);*/
		
	}

}
