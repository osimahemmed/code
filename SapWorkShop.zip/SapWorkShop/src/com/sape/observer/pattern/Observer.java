package com.sape.observer.pattern;

public interface Observer {
	
	public void update(String productName);

}
