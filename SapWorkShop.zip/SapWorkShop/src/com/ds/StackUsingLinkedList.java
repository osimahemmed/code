package com.ds;

public class StackUsingLinkedList {
	
	private Node head;
	
	private class Node {
		int data;
		Node next;
		public Node(int data) {
			this.data = data;
			next = null;
		}
	}
	
	private void push(int new_data) {
		Node new_node = new Node(new_data);
		new_node.next = head;
		head = new_node;
		
	}
	
	private int pop() throws LinkedListEmptyException {
		if(head == null) {
			throw new LinkedListEmptyException();
		}
		int value = head.data;
		head = head.next;
		return value;
	}
	
	private void printList() {
		while(head != null) {
			System.out.println(head.data);
			head = head.next;
		}
		System.out.println();
	}
	
	public static void main(String [] args) {
		StackUsingLinkedList stack = new StackUsingLinkedList();
			stack.push(20);
			stack.push(50);
			stack.push(80);
			stack.push(90);
			//stack.push(60);
			//stack.push(75);
			//stack.printList();
			
			System.out.println("Element removed from LinkedList: "+stack.pop());  
	        System.out.println("Element removed from LinkedList: "+stack.pop());  
	        //stack.push(10);  
	        System.out.println("Element removed from LinkedList: "+stack.pop());  
	        stack.printList();

	}
}
