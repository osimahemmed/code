package com.oracle.xml;

public class ImmutableString {

	public static void main(String[] args) {
		
		String name = "osim";
		name.concat("osim");
		System.out.println(name);
		name = "test123";
		System.out.println(name);

	}

}
