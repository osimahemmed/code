package com.abc.test;

public class MyExc3 extends MyExc2 {

}
