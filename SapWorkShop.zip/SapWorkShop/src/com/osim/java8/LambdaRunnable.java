package com.osim.java8;

public class LambdaRunnable {

	public static void main(String[] args) {
		
		Runnable task = () -> {
			for(int i = 0; i <= 10; i++) {
				System.out.println("Inside run method " + i);
			}
			//System.out.println("Inside run method");
		};
		
		new Thread(task).start();

	}

}
