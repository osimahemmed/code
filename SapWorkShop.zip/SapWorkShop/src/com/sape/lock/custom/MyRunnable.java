package com.sape.lock.custom;

class MyRunnable implements Runnable{

   	ICustomLock lockCustom;

   	public MyRunnable(ICustomLock LockCustom) {  	
      		this.lockCustom=LockCustom;
   	}

   	public void run(){
      		System.out.println(Thread.currentThread().getName() +" is Waiting to acquire LockCustom");
      		lockCustom.lock();
      		System.out.println(Thread.currentThread().getName() +" has acquired LockCustom.");
      		try {
             		Thread.sleep(5000);
             		System.out.println(Thread.currentThread().getName() +" is sleeping.");
      		} catch (InterruptedException e) {
             		e.printStackTrace();
      		}
      		System.out.println(Thread.currentThread().getName()

                   		+" has released LockCustom.");
      		lockCustom.unlock();

   	}

}
