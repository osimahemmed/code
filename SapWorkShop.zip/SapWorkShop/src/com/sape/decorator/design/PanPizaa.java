package com.sape.decorator.design;

public class PanPizaa implements Pizza {

	@Override
	public String descriotion() {
		return "Pan Pizza";
	}

	@Override
	public Double cost() {
		return 10.0;
	}

}
