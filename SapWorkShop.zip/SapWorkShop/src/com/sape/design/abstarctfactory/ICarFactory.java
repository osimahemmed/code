package com.sape.design.abstarctfactory;

public interface ICarFactory {
	ICar createCar(String carType);
}


