package com.osim.java8;

public class StringConcatTest {

	public static void main(String[] args) {
		
		StringConcat con = (str1, str2) -> str1+str2;
		
		System.out.println("cpncat " + con.sconcat("osim", "ahemmed"));

	}

}
