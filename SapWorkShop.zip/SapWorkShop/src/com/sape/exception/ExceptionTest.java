package com.sape.exception;

import java.io.IOException;

public class ExceptionTest {
    public static void main(String[] args) throws IOException {
    	/*try {
            method1();
            System.out.println("After calling m()");
		} catch (Exception e) {
			System.out.println("handled null pointer");
		}*/
           method1();
           System.out.println("After calling m()");
    }
    
    static void method1() {
    	method2();
    }
    static void method2() {
    	method3();
    }
    static void method3() {
    	throw new NullPointerException();
    }
}
