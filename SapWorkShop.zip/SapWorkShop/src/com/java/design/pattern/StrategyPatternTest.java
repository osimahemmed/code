package com.java.design.pattern;

public class StrategyPatternTest {

	public static void main(String[] args) {
		
		Context context = new Context(new OperationAdd());
		System.out.println("10 + 5 = " + context.executeStrategy(10, 5));

	}

}
