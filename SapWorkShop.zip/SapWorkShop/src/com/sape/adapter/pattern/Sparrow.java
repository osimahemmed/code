package com.sape.adapter.pattern;

public class Sparrow implements IBird {

	public void fly() {
		System.out.println("Flying");
		
	}

	public void makeSound() {
		System.out.println("Chirp Chirp");
		
	}

	
}
