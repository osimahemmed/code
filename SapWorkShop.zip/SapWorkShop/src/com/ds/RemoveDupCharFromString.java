package com.ds;

public class RemoveDupCharFromString {

	public static void main(String[] args) {
	
		String na = removeDupChar("java");
		System.out.println(na);

	}
	
	private static String removeDupChar(String name) {
		
		String result = "";
		/*for(int i = 0; i < name.length(); i++) {
			if(!result.contains(""+name.charAt(i))) {
				result +=""+name.charAt(i);
			}
		}*/
		for(int i = 0; i < name.length(); i++) {
			if(!result.contains(""+name.charAt(i))) {
				result += ""+name.charAt(i);
			}
		}
		return result;
		/*String result = "";
		for(int i=0; i < name.length(); i++) {
			if(!result.contains(""+name.charAt(i))) {
				result += "" + name.charAt(i); 
			}
		}
		return result;*/
	}

}
