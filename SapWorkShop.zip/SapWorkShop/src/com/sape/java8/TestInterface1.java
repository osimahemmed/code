package com.sape.java8;

public interface TestInterface1 {

	default void show() {
		System.out.println("default TestInterface1");
	}
}
