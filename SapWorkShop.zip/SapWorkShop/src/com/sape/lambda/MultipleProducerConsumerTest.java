package com.sape.lambda;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class MultipleProducerConsumerTest {



	public static void main(String[] args) {
		int NUMBER_PRODUCER = 1, NUMBER_CONSUMER = 2;
		AtomicInteger activeProducers = new AtomicInteger();
		BlockingQueue<Integer> queue = new ArrayBlockingQueue<>(10);

		Thread producer = new Thread(() -> {
			String threadName = Thread.currentThread().getName();
			try {
				for(int i=0;i<5;i++) {
					Thread.sleep(TimeUnit.SECONDS.toMillis(1));
					queue.put(i);
					System.out.println("Produced "+i +" by "+threadName);
				} 
			} catch(InterruptedException ie) {
				System.out.println(" Producer terminates early: "+ie);
				ie.printStackTrace();
			} finally {
				activeProducers.decrementAndGet();
			}
		});
		
		Thread consumer = new Thread(() ->  {
			String threadName = Thread.currentThread().getName();
			try {
				while(true) {
					Integer num = queue.poll(1,TimeUnit.SECONDS);
					if(num != null) {
						System.out.println("Consumed : "+num+" by "+threadName);
					} else if(activeProducers.get() == 0 && queue.peek() == null) {
						return;
					}
				}
			} catch(InterruptedException ie) {
				System.out.println(" Consumers terminates early: "+ie);
				ie.printStackTrace();
			}
		});

		for(int i=0;i<NUMBER_PRODUCER;i++) {
			activeProducers.incrementAndGet();
			new Thread(producer).start();
		}
		for(int i=0; i<NUMBER_CONSUMER; i++) {
			  new Thread(consumer).start();
			}
	}

}
