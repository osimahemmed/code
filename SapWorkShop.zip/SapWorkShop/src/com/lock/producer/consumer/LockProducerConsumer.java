package com.lock.producer.consumer;

import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class LockProducerConsumer {

	public static void main(String[] args) {
		
		Queue<Integer> queue = new LinkedList<Integer>();
		Lock lock = new ReentrantLock();
		
		Condition prdCon = lock.newCondition();
		Condition conCon = lock.newCondition();
		
		final int size = 5;
		
		new Producer(lock, prdCon, conCon, queue, size).start();
		new Consumer(lock, prdCon, conCon,  queue).start();

	}

}
