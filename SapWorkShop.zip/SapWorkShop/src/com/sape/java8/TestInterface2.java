package com.sape.java8;

public interface TestInterface2 {

	default void show() {
		System.out.println(" default TestInterface2");
	}
}
