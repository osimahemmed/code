package com.common;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class MemoryLeakExample {
	public static void main(String[] args) {
		
		Random random = new Random();
		Map<Object, Object> sampleMap = new HashMap<Object, Object>();
		
		try {
			while(true) {
				int randomVal = random.nextInt();
				sampleMap.put(randomVal, String.valueOf(randomVal));
				System.out.println(randomVal);
			}
		} catch (OutOfMemoryError e) {
			//e.printStackTrace();
			System.out.println("catching exception "+ e.getMessage());
		}
		
	}

}
