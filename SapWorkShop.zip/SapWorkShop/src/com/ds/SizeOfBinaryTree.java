package com.ds;

import java.util.Queue;

public class SizeOfBinaryTree {
	
	static class Node {
		int data;
		Node left, right;
		public Node(int data) {
			this.data = data;
			left = right = null;
		}
	}
	
	private static int getSize(Node root) {
		if(root == null)
			return 0;
		return 1 + getSize(root.left) + getSize(root.right);
		
	}
	
	private static int findSize(Node root) {
		if(root == null)
			return 0;
		int size = 0;
		
		Queue<Node> queue = new java.util.LinkedList<>();
		queue.add(root);
		while(!queue.isEmpty()) {
			Node temp = queue.poll();
			size ++;
			
			if(temp.left != null) {
				queue.add(temp.left);
			}
			if(temp.right != null) {
				queue.add(temp.right);
			}
		}
		return size;
	}

	public static void main(String[] args) {
		
		Node root = new Node(5);
		root.left = new Node(15);
		root.right = new Node(25);
		root.left.left = new Node(20);
		root.left.right = new Node(30);
		root.right.left = new Node(2);
		root.right.right = new Node(10);
		
		System.out.println("Size of a tree is " + getSize(root));
		System.out.println("Size of a tree in iteratve arrpoach is "+findSize(root) );
	}

}
