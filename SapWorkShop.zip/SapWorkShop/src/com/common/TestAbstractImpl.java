package com.common;

public class TestAbstractImpl extends TestAbstract {
	public static void main(String[] args) {
		System.out.println(TestAbstractImpl.test());
	}
}
