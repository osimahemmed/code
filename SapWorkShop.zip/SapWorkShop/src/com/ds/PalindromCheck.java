package com.ds;

public class PalindromCheck {

	public static void main(String[] args) {
		
		//boolean b = isPalindrome("ammas");
		boolean c = palindromTest("abaa");

		//System.out.println(b);
		System.out.println("is palindrome " +c);

	}
	
	private static boolean isPalindrome(String s) {
		int i = 0;
		int j = s.length()-1;
		while(i < j) {
			if(s.charAt(i) != s.charAt(j)) {
				return false;
			}
			i++;
			j--;
		}
		return true;
	}

	/*private static boolean palindromTest(String str) {
		
		boolean palin = true;
		int n = str.length();
		for(int i = 0; i < n/2; i++) {
			if(str.charAt(i) != str.charAt(n-i-1)) {
				palin = false;
			} else {
				palin = true;
			}
		}
		return palin;
		
		
	}*/
	
	private static boolean palindromTest(String str) {
		
		boolean palin = true;
		int n = str.length();
		
		for(int i = 0; i < n/2; i ++) {
			if(str.charAt(i) != str.charAt(n-i-1)) {
				palin = false;
			} else {
				palin = true;
			}
		}
		
		return palin;
		
	}
}
