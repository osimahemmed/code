package com.ds;

import java.util.Arrays;

public class RotationOfString {

	public static void main(String[] arg) 
	{

		/*int n = 2;
		String str1 = "helloworld";
		//right rotate
		String ri = str1.substring(str1.length()-n);
		String le = str1.substring(0, str1.length()-n);
		System.out.println(ri+le);
		//end right rotate
		String l = str1.substring(0,n);
		String r = str1.substring(n);
		System.out.println(r+l);*/

		String str = "abcdef"; //fabcde//efabcd//defabc//3 times rotated
		char[] A = str.toCharArray();
		int offset = 3;
		char[] chArr =  rotateOptimized(A, offset);
		System.out.println(new String(chArr));
		// System.out.println("\n"+Arrays.toString(A));
	}

	private static char[] reverse(char[] charArr, int start, int end) {
		while (start <= end) {
			char temp = charArr[start];
			charArr[start] = charArr[end];
			charArr[end] = temp;
			start++;
			end--;
		}
		return charArr;
	}

	public static char[] rotateOptimized(char[] charArr,int k)
	{
		int n = charArr.length;
		if(k > n) 
			k = k % n;
		charArr = reverse(charArr, 0, n-1);
		charArr = reverse(charArr, 0, k-1);
		charArr = reverse(charArr, k, n-1);
		
		return charArr;
	}

}
