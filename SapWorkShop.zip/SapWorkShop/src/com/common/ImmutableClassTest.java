package com.common;

import java.util.Date;

public class ImmutableClassTest {
	
	public static void main(String[] args)
    {
    	
    	String name ="FAST   ";
    	
    	System.out.println(name.trim());
        Immutable im = Immutable.createNewInstance(100,"test", new Date());
        System.out.println(im);
        tryModification(im.getImmutableField1(),im.getImmutableField2(),im.getMutableFiled());
        System.out.println(im);
    }
 
    private static void tryModification(Integer immutableField1, String immutableField2, Date mutableField)
    {
        immutableField1 = 10000;
        immutableField2 = "test changed";
        mutableField.setDate(10);
    }

}
