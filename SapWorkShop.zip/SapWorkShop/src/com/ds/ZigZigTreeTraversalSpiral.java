
/*
  
	    1
	  /  \
	 2    3
	/ \   / \
   7  6  5  4
 
 
 */
package com.ds;

import java.util.Stack;

public class ZigZigTreeTraversalSpiral {

	static class Node {
		int data;
		Node left, right;

		public Node(int d) {
			data = d;
			left = right = null;
		}
		
		public String toString() {
			return "[" +" left = " + left +" right = " + right +" data= " +data + " ] ";
		}
		
	}

	static Node root;

	void printSpiral(Node node) {
		
		if (node == null)
			return; // NULL check

		// Create two stacks to store alternate levels
		Stack<Node> s1 = new Stack<Node>();// For levels to be printed from
		// right to left
		Stack<Node> s2 = new Stack<Node>();// For levels to be printed from left
		// to right

		// Push first level to first stack 's1'
		s1.push(node);

		// Keep printing while any of the stacks has some nodes
		while (!s1.empty() || !s2.empty()) {
			// Print nodes of current level from s1 and push nodes of
			// next level to s2
			while (!s1.empty()) {
				//Node temp = s1.peek();
				node  = s1.pop();
				//s1.pop();
				System.out.print(node.data + " ");

				// Note that is left is pushed before right

				if (node.left != null)
					s2.push(node.left);

				if (node.right != null)
					s2.push(node.right);
			}

			// Print nodes of current level from s2 and push nodes of
			// next level to s1
			while (!s2.empty()) {
				//Node temp = s2.peek();
				node = s2.pop();
				//s2.pop();
				System.out.print(node.data + " ");

				// Note that is right is pushed before left
				if (node.right != null)
					s1.push(node.right);
				if (node.left != null)
					s1.push(node.left);
				
			}
		}

	}

	public static void main(String[] args) {
		ZigZigTreeTraversalSpiral tree = new ZigZigTreeTraversalSpiral();
		tree.root = new Node(1);
		tree.root.left = new Node(2);
		tree.root.right = new Node(3);
		tree.root.left.left = new Node(7);
		tree.root.left.right = new Node(6);
		tree.root.right.left = new Node(5);
		tree.root.right.right = new Node(4);
		System.out.println("Spiral Order traversal of Binary Tree is ");
		tree.printSpiral(root);
	}
}