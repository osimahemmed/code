package com.sape.multiconsumer;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class ProducerConsumerTest {

	public static void main(String[] args) {
		BlockingQueue<Integer> queue = new ArrayBlockingQueue<>(20);
		
		Thread producer1 = new Thread(new Producer(queue),"producer1");
		//Thread producer2 = new Thread(new Producer(queue),"producer2");
		//Thread producer3 = new Thread(new Producer(queue),"producer3");
		Thread consumer1 = new Thread(new Consumer(queue),"consumer1");
		Thread consumer2 = new Thread(new Consumer(queue),"consumer2");
		Thread consumer3 = new Thread(new Consumer(queue),"consumer3");
		
		producer1.start();
		//producer2.start();
		//producer3.start();
		consumer1.start();
		consumer2.start();
		consumer3.start();

	}

}
