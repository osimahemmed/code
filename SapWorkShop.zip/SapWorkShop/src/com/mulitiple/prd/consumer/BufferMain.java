package com.mulitiple.prd.consumer;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class BufferMain {

	public static void main(String[] args) {

		Buffer buffer = new Buffer(5);

		BufferProducer bufferProducer = new BufferProducer(buffer);
		BufferConsumer bufferConsumer = new BufferConsumer(buffer);

		ExecutorService producerExecutor = Executors.newFixedThreadPool(10);
		for (int i = 0; i < 10; i++) {
			producerExecutor.execute(bufferProducer);
		}

		ExecutorService consumerExecutor = Executors.newFixedThreadPool(10);
		for (int i = 0; i < 10; i++) {
			consumerExecutor.execute(bufferConsumer);
		}

		producerExecutor.shutdown();
		consumerExecutor.shutdown();	

	}
}
