package com.sape.multiconsumer;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

/*
 * In case there are multiple consumer threads, we should use the poll(time, unit) method to 
 * take elements from the head of the queue. This method does not wait forever like the take() method. 
 * Instead, it just waits for a specified of time. The lock is released either when an element found or 
 * the time out period expires.This avoids deadlock among different consumer threads.
 */

public class Consumer implements Runnable {
	
	private BlockingQueue<Integer> queue;
	private String threadName;
	public Consumer(BlockingQueue<Integer> queue) {
		this.queue = queue;
	}

	@Override
	public void run() {
		threadName = Thread.currentThread().getName();
		try {
			while(true) {
				Integer number  = queue.poll(5, TimeUnit.SECONDS);
				if(number == null || number == -1) {
					break;
				}
				consume(number);
			}
			System.out.println(threadName +" Stopped");
		} catch (InterruptedException ie) {
			ie.printStackTrace();
		}
		
	}
	
	private void consume(Integer number) {
		System.out.println(threadName + ": Consuming number <= " + number);
	}

}
