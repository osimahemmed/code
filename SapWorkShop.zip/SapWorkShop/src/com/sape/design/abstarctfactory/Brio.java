package com.sape.design.abstarctfactory;

public class Brio implements ICar{

	@Override
	public void drive() {
		System.out.println("Driving BRIO");
		
	}

}
