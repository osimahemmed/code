package com.common;

public class FractionAddition {

	public static void main(String[] args) {
		
		int a = 1/2;
		int b = 3/2;
		
		int nom1 = 3/2;
		int denom1 = 3%2;
		
		System.out.println(nom1 + " denom1 " + denom1);
		
		

	}
	
	private static void add(int nom1, int denom1, int nom2, int denom2){

	    int comd = denom1*denom2; //creates common denominator by multiplying both denominators

	    int newNomAnswer = nom1*denom2 + nom2*denom1;


	    System.out.println(nom1 + "/" + denom1 + " + " + nom2 + "/" + denom2 + " = " + newNomAnswer + "/" + comd);

	     
	}

}
