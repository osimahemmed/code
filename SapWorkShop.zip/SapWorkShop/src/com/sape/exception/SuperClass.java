package com.sape.exception;

import java.io.IOException;

class SuperClass {
    void method() throws NullPointerException {
           System.out.println("superClass method");
    }
}
