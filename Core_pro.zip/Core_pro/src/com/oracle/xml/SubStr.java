package com.oracle.xml;

public class SubStr {

	public static void main(String[] args) {
		String str = "osimah";
		System.out.println("str"+str.length());
		str = str.substring(1, 5);
		System.out.println(str);

	}

}
