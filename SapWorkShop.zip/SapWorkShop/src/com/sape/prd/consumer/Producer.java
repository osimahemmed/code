package com.sape.prd.consumer;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

public class Producer implements Runnable {
	AtomicInteger atomicInt;
	BlockingQueue<Integer> sharedQueue;
	String threadName;
	public Producer(BlockingQueue<Integer> queue, AtomicInteger atomicInt) {
		this.sharedQueue = queue;
		this.atomicInt = atomicInt;
	}
	@Override
	public void run() {
		threadName = Thread.currentThread().getName();
		//int atomic = atomicInt.get();
		for(int i = 1; i <= 5; i++) {
			try {
				int num = i*2;
				System.out.println("Produced number "+  num + " by "+threadName);
				sharedQueue.put(num);
				Thread.sleep(2000);
				atomicInt.incrementAndGet();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
