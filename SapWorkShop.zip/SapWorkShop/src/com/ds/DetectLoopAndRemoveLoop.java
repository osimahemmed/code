package com.ds;

public class DetectLoopAndRemoveLoop {

	static Node head;
	
	static class Node {
		Node next;
		int data;
		public Node(int d) {
			data = d;
			next = null;
		}
	}
	
	void detectRemoveLoop(Node node) {
		Node slow = node;
		Node fast = node.next;
		while(fast != null && fast.next != null) {
			if(slow == fast) {
				System.out.println("Loop exists");
				break;
			}
			slow = slow.next;
			fast = fast.next.next;
		}
		
		/* If loop exists */
		if(slow == fast) {
			slow = node;
			while(slow != fast.next) {
				slow = slow.next;
				fast = fast.next;
			}
			/* since fast->next is the looping point */
			fast.next = null;///* remove loop */
		}
		
	}
	
	void printLinkedList(Node node) {
		while(node != null) {
			System.out.println(node.data);
			node = node.next;
		}
	}
	
	public static void main(String args[]) {
		DetectLoopAndRemoveLoop list = new DetectLoopAndRemoveLoop();
		list.head = new Node(50);
		list.head.next = new Node(20);
		list.head.next.next = new Node(15);
		list.head.next.next.next = new Node(4);
		list.head.next.next.next.next = new Node(10);
		
		head.next.next.next.next.next = head.next.next;
		System.out.println("Detecting loop");
		list.detectRemoveLoop(head);
		System.out.println("LinkedList after loop removal");
		list.printLinkedList(head);
		list.detectRemoveLoop(head);
	}
}
