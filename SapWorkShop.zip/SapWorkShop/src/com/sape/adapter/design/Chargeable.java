package com.sape.adapter.design;

public interface Chargeable {
	
	public void setMobileName(String mobileName);
	public void charge();

}
