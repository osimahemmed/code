package com.java.design.pattern;

public class FactoryDemo {

	public static void main(String[] args) {

		ShapeFactory shape = new ShapeFactory();
		
		Shape shape1 = shape.getShape("Circle");
		shape1.draw();
		Shape shape2 = shape.getShape("Square");
		shape2.draw();
		Shape shape3 = shape.getShape("Rectangle");
		shape3.draw();

	}

}
