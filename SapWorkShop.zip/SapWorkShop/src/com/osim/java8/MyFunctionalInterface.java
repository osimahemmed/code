package com.osim.java8;

@FunctionalInterface
public interface MyFunctionalInterface {
	public int add(int a, int b);
}
