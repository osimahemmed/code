package com.common;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class EvenOddTest {
	


public static void main(String[] args) throws InterruptedException {
    
        final Lock lock = new ReentrantLock();
        final Condition evenCondition =  lock.newCondition();
        final Condition oddCondition =  lock.newCondition();
        final CountDownLatch latch = new CountDownLatch(1);
        
        Thread odd = new Thread(){
            @Override
            public void run(){
                try{
                    lock.lock();
                    for(int i=1; i<=10; i=i+2){
                        System.out.println("ODD - " + i);
                        evenCondition.signalAll();
                        oddCondition.await();
                    }                    
                }
                catch(InterruptedException ex){
                    //ignore
                }
                finally{
                    evenCondition.signalAll();
                    lock.unlock();
                }
            }
        };
        
        Thread even = new Thread(){
            @Override
            public void run(){
                try{
                    lock.lock();
                    latch.countDown();
                    for(int i=0; i<=10; i=i+2){
                        System.out.println("EVEN - " + i);
                        oddCondition.signalAll();
                        evenCondition.await(); 
                    }                    
                }
                catch(InterruptedException ex){
                    //ignore
                }
                finally{
                    oddCondition.signalAll();
                    lock.unlock();
                } 
            }
        };
        
        //odd.start();
        //latch.await();
        even.start();
        latch.await();
        odd.start();

    }

}
