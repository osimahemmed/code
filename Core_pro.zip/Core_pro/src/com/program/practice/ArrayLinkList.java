package com.program.practice;

public class ArrayLinkList {

	public static void main(String[] args) {
		
		int[]  A = {1 , 4, -1, 3, 2};
		
		int count = countLoops(A);
		System.out.println(count);

	}

	/**
	 * @param A
	 */
	private static int countLoops(int[] A) {
		int length = 0;
		int value = 0;
		int index = 0;
		
		while(value != -1) {
			value = A[index];
			length ++;
			index  = value;
		}
		return length;
	}

}