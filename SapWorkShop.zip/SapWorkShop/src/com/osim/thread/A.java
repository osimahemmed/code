package com.osim.thread;

public class A {
	
	public void method1() {
		System.out.println("Super class method1 ");
	}

}
