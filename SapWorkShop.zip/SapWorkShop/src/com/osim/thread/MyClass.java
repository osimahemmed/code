package com.osim.thread;

public class MyClass {

	
	public static void main(String args[]) throws InterruptedException{
		 
        MyRunnable1 object1=new MyRunnable1();
        MyRunnable1 object2=new MyRunnable1();
        
        Thread thread1=new Thread(object1,"Thread-1");
        Thread thread2=new Thread(object2,"Thread-2");
        thread1.start();        
        Thread.sleep(10);//Just to ensure Thread-1 starts before Thread-2
        thread2.start();        
        
        
 }
}
